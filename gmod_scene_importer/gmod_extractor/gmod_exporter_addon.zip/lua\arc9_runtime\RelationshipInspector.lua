-- RelationshipInspector.lua
-- Inspects and documents structural parenting connections.

return function(db, wep, vm)
    db.scene = {
        nodes = {}
    }

    -- Root weapon node
    table.insert(db.scene.nodes, {
        id = "node_weapon_root",
        name = "WeaponRoot",
        parent = nil,
        parent_type = "ROOT",
        transform = {
            position = {0.0, 0.0, 0.0},
            rotation = {0.0, 0.0, 0.0, 1.0},
            scale = {1.0, 1.0, 1.0}
        }
    })

    -- Process all entities
    for guid_str, ent in pairs(db.guid_to_entity) do
        local parent = ent:GetParent()
        if not IsValid(parent) then
            parent = ent:GetMoveParent()
        end

        local parent_id = "node_weapon_root"
        if IsValid(parent) and db.entity_to_guid[parent] then
            parent_id = db.entity_to_guid[parent]
        end

        local parent_type = "OBJECT"
        local parent_bone = nil
        local parent_attachment = nil

        -- Check slot bone names from ARC9 properties
        local bone_name = ent.Bone or (ent.slottbl and ent.slottbl.Bone) or ""
        
        -- Fallback to engine parent attachment index
        local att_id = ent:GetParentAttachment()
        if att_id and att_id > 0 and IsValid(parent) then
            local att_name = parent:GetAttachmentName(att_id)
            if att_name and att_name ~= "" then
                parent_type = "ATTACHMENT"
                parent_attachment = att_name
            end
        end

        if bone_name ~= "" and IsValid(parent) then
            local bone_idx = parent:LookupBone(bone_name)
            if bone_idx and bone_idx >= 0 then
                parent_type = "BONE"
                parent_bone = bone_name
            else
                local att_idx = parent:LookupAttachment(bone_name)
                if att_idx and att_idx > 0 then
                    parent_type = "ATTACHMENT"
                    parent_attachment = bone_name
                end
            end
        end

        table.insert(db.scene.nodes, {
            id = guid_str,
            name = ent:GetClass() or "Entity",
            resource_id = "res_" .. guid_str,
            parent = parent_id,
            parent_type = parent_type,
            parent_bone = parent_bone,
            parent_attachment = parent_attachment
        })
    end
end
