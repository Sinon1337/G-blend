-- TransformInspector.lua  (rewrite)
-- Position : entity:GetPos()                   — always correct for all entities
-- Angle    : for C_BaseFlex use the nearest    — viewmodel bone orientation
--            viewmodel bone's angle             — (viewmodel bones are always correct in ARC9)
--          : for viewmodel/gmod_hands use       — entity:GetAngles()

return function(db, wep, vm)
    local ref_ent = IsValid(vm) and vm or wep
    local ref_pos = ref_ent:GetPos()
    local ref_ang = ref_ent:GetAngles()

    -- Build viewmodel bone table once (position + angle for every valid bone)
    local vm_bones = {}
    if IsValid(vm) then
        vm:SetupBones()
        local n = vm:GetBoneCount() or 0
        for i = 0, n - 1 do
            local bm = vm:GetBoneMatrix(i)
            if bm then
                vm_bones[#vm_bones + 1] = { pos = bm:GetTranslation(), ang = bm:GetAngles() }
            end
        end
    end

    for guid_str, ent in pairs(db.guid_to_entity) do
        local ent_world_pos = ent:GetPos()
        local ent_world_ang = ent:GetAngles()

        -- C_BaseFlex: GetAngles() is always [0,0,0] because ARC9 uses bone-merge.
        -- Find the viewmodel bone closest to the entity's world position — that is
        -- the bone it is merged to, so its orientation = the attachment's true orientation.
        if ent:GetClass() == "class C_BaseFlex" and #vm_bones > 0 then
            local best_dist = math.huge
            for _, bone in ipairs(vm_bones) do
                local d = (bone.pos - ent_world_pos):Length()
                if d < best_dist then
                    best_dist = d
                    ent_world_ang = bone.ang
                end
            end
        end

        -- Convert to weapon-root local space
        local local_pos, _ = WorldToLocal(ent_world_pos, Angle(0, 0, 0), ref_pos, ref_ang)
        local _, local_ang  = WorldToLocal(ref_pos, ent_world_ang,       ref_pos, ref_ang)

        for _, node in ipairs(db.scene.nodes) do
            if node.id == guid_str then
                node.pos = { local_pos.x, local_pos.y, local_pos.z }
                node.ang = { local_ang.p, local_ang.y, local_ang.r }
                break
            end
        end
    end
end
