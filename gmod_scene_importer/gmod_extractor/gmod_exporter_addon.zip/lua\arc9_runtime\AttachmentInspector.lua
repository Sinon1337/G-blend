-- AttachmentInspector.lua
-- Scans all engine (QC) attachments and records their coordinates.

return function(db, wep, vm)
    db.attachments = {}

    for guid_str, ent in pairs(db.guid_to_entity) do
        local attachments = ent:GetAttachments() or {}
        if #attachments > 0 then
            local ent_atts = {}
            local ent_mat = Matrix()
            ent_mat:Identity()
            ent_mat:SetTranslation(ent:GetPos())
            ent_mat:SetAngles(ent:GetAngles())
            local ent_mat_inv = ent_mat:GetInverse()

            for _, att in ipairs(attachments) do
                local att_id = att.id
                local att_name = att.name
                local att_data = ent:GetAttachment(att_id)
                if att_data then
                    local att_mat = Matrix()
                    att_mat:Identity()
                    att_mat:SetTranslation(att_data.Pos)
                    att_mat:SetAngles(att_data.Ang)

                    -- Relative to entity origin
                    local loc_mat = ent_mat_inv * att_mat

                    table.insert(ent_atts, {
                        id = att_id,
                        name = att_name,
                        world_matrix = att_mat:ToTable(),
                        local_matrix = loc_mat:ToTable()
                    })
                end
            end
            db.attachments[guid_str] = ent_atts
        end
    end
end
