ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.GetRenderState(ent)
    local render = {
        skin = ent:GetSkin() or 0,
        bodygroups = {},
        materials = {},
        color = ent:GetColor()
    }
    
    for i = 0, ent:GetNumBodyGroups() - 1 do
        local bg_name = ent:GetBodygroupName(i)
        render.bodygroups[bg_name] = ent:GetBodygroup(i)
    end
    
    local submats = ent:GetMaterials() or {}
    for i, mat in ipairs(submats) do
        local override = ent:GetSubMaterial(i - 1)
        if override and override ~= "" then
            table.insert(render.materials, override)
        else
            table.insert(render.materials, mat)
        end
    end
    
    return render
end
