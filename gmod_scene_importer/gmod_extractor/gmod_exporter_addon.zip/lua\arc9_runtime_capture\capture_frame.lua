ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.GetFrameData(vm, weapon, ply)
    local cam_pos = EyePos()
    local cam_ang = EyeAngles()
    
    local cam_mat = Matrix()
    cam_mat:SetTranslation(cam_pos)
    cam_mat:SetAngles(cam_ang)
    
    local cam_arr = {}
    for r = 1, 4 do
        for c = 1, 4 do
            table.insert(cam_arr, cam_mat:GetField(r, c))
        end
    end
    
    return {
        weapon = IsValid(weapon) and weapon:GetClass() or "unknown",
        viewmodel_fov = ply:GetFOV(),
        camera_matrix = cam_arr,
        frame = FrameNumber(),
        sequence = IsValid(vm) and vm:GetSequence() or 0,
        cycle = IsValid(vm) and vm:GetCycle() or 0
    }
end
