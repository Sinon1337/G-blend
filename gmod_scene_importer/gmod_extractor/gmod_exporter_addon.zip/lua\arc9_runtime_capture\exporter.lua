ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.ExportFrame(vm, weapon, ply)
    local hands = ply:GetHands()
    
    local data = {
        format = "ARC9_RUNTIME_FRAME",
        capture = ARC9_CAPTURE.GetFrameData(vm, weapon, ply),
        objects = {
            meshes = {},
            attachments = {},
            hands = {}
        },
        skeletons = {}
    }
    
    local candidates = ARC9_CAPTURE.GetCandidates(vm, weapon, hands)
    
    for ent, _ in pairs(candidates) do
        local id = tostring(ent:EntIndex())
        if id == "-1" then
            id = tostring(ent)
        end
        
        local is_hands = (ent == hands)
        
        local obj_data = {
            id = id,
            type = "static_mesh",
            model = ent:GetModel(),
            transform = {
                space = "world",
                matrix = ARC9_CAPTURE.GetRenderMatrix(ent)
            },
            render = ARC9_CAPTURE.GetRenderState(ent)
        }
        
        if is_hands then
            table.insert(data.objects.hands, obj_data)
        else
            table.insert(data.objects.meshes, obj_data)
        end
    end
    
    if IsValid(vm) then
        local id = tostring(vm:EntIndex())
        if id == "-1" then id = tostring(vm) end
        table.insert(data.skeletons, {
            id = "weapon_vm",
            object = id,
            space = "world",
            bones = ARC9_CAPTURE.GetSkeleton(vm)
        })
    end
    
    if IsValid(hands) then
        local id = tostring(hands:EntIndex())
        if id == "-1" then id = tostring(hands) end
        table.insert(data.skeletons, {
            id = "hands",
            object = id,
            space = "world",
            bones = ARC9_CAPTURE.GetSkeleton(hands)
        })
    end
    
    local json_str = util.TableToJSON(data, true)
    if not file.Exists("gmod_blender", "DATA") then
        file.CreateDir("gmod_blender")
    end
    file.Write("gmod_blender/arc9_runtime_frame.json", json_str)
    print("[ARC9 Capture] Saved to data/gmod_blender/arc9_runtime_frame.json")
end
