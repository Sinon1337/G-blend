-- RuntimeInspector.lua
-- Captures extra runtime flags (visibility, no-draw state, effects, scale, LOD).

return function(db, wep, vm)
    db.runtime = {}

    for guid_str, ent in pairs(db.guid_to_entity) do
        db.runtime[guid_str] = {
            entity_id = guid_str,
            visible = not ent:GetNoDraw(),
            nodraw = ent:GetNoDraw(),
            effects = ent:GetEffects() or 0,
            scale = ent:GetModelScale() or 1.0
        }
    end
end
