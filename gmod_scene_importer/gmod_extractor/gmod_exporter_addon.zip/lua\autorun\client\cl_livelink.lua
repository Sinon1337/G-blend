-- cl_livelink.lua
-- Real-time synchronization client for GMod-Blender Live Link
-- Uses a hidden off-screen Chromium DHTML panel to bypass Garry's Mod client-side loopback HTTP restrictions
--

CreateClientConVar("gmod_livelink_host", "127.0.0.1", true, false, "IP/Host for Blender Live Link HTTP Server")
CreateClientConVar("gmod_livelink_port", "8000", true, false, "Port for Blender Live Link HTTP Server")

local gmod_livelink_running = false

-- Cleanup old panel if it was left from a previous script reload
if IsValid(GMod_LiveLinkHTML) then
    GMod_LiveLinkHTML:Remove()
end
GMod_LiveLinkHTML = nil

local next_sync_time = 0
local sync_interval = 0.03 -- ~30 sync updates per second (33ms)

local function SendPlayerUpdate()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    -- Initialize hidden DHTML bridge if not already created
    if not IsValid(GMod_LiveLinkHTML) then
        local host = GetConVar("gmod_livelink_host"):GetString()
        local port = GetConVar("gmod_livelink_port"):GetInt()
        
        GMod_LiveLinkHTML = vgui.Create("DHTML")
        GMod_LiveLinkHTML:SetSize(1, 1)
        GMod_LiveLinkHTML:SetPos(-10, -10) -- Off-screen
        
        -- Expose callback function to Javascript in Chromium
        GMod_LiveLinkHTML:AddFunction("gmod", "pollCallback", function(dataJson)
            local data = util.JSONToTable(dataJson)
            if data and #data > 0 then
                for _, packet in ipairs(data) do
                    if packet.type == "player_teleport" then
                        local posTable = packet.pos
                        local angTable = packet.ang
                        RunConsoleCommand("gmod_livelink_teleport", 
                            tostring(posTable[1]), tostring(posTable[2]), tostring(posTable[3]), 
                            tostring(angTable[1]), tostring(angTable[2]), tostring(angTable[3])
                        )
                    elseif packet.type == "entity_transform" then
                        local entName = packet.name
                        local posTable = packet.pos
                        local angTable = packet.ang
                        
                        local ent = nil
                        if packet.gmod_id then
                            ent = Entity(packet.gmod_id)
                        end
                        
                        -- Find matching prop in GMod client-side and update its transform
                        if not IsValid(ent) then
                            for _, e in ipairs(ents.GetAll()) do
                                if e:GetName() == entName or (e:GetClass() == "prop_physics" and e:GetModel() and string.find(e:GetModel(), entName)) then
                                    ent = e
                                    break
                                end
                            end
                        end
                        
                        if IsValid(ent) then
                            local newPos = Vector(posTable[1], posTable[2], posTable[3])
                            local newAng = Angle(angTable[1], angTable[2], angTable[3])
                            
                            ent:SetPos(newPos)
                            ent:SetAngles(newAng)
                            
                            local phys = ent:GetPhysicsObject()
                            if IsValid(phys) then
                                phys:EnableMotion(false)
                            end
                        end
                    end
                end
            end
        end)
        
        GMod_LiveLinkHTML:OpenURL("http://" .. host .. ":" .. port .. "/")
    end

    local pos = ply:GetPos()
    local ang = ply:EyeAngles()

    -- Call JS function in the Chromium container to send transform to Blender (safely check if defined)
    local js = string.format("if (typeof sendUpdate !== 'undefined') { sendUpdate(%f, %f, %f, %f, %f, %f); }", pos.x, pos.y, pos.z, ang.p, ang.y, ang.r)
    GMod_LiveLinkHTML:QueueJavascript(js)
end

local function LiveLinkTick()
    if not gmod_livelink_running then return end

    local time = RealTime()
    if time >= next_sync_time then
        next_sync_time = time + sync_interval
        SendPlayerUpdate()
    end
end

concommand.Add("gmod_livelink_start", function()
    if gmod_livelink_running then
        print("[GModLiveLink] Live Link is already running.")
        return
    end

    gmod_livelink_running = true
    hook.Add("Think", "GMod_LiveLink_Sync", LiveLinkTick)
    print("[GModLiveLink] Real-time Live Link started (via Chromium Bridge)!")
end)

concommand.Add("gmod_livelink_stop", function()
    gmod_livelink_running = false
    hook.Remove("Think", "GMod_LiveLink_Sync")
    
    -- Cleanup DHTML panel
    if IsValid(GMod_LiveLinkHTML) then
        GMod_LiveLinkHTML:Remove()
        GMod_LiveLinkHTML = nil
    end
    
    print("[GModLiveLink] Real-time Live Link stopped.")
end)
