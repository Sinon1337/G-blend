-- MaterialInspector.lua
-- Captures material lists, submaterial overrides, skin indices, color tints, and opacity.

return function(db, wep, vm)
    db.materials = {}

    for guid_str, ent in pairs(db.guid_to_entity) do
        local mats = ent:GetMaterials() or {}
        local overrides = {}
        for i = 0, 31 do
            local sub = ent:GetSubMaterial(i)
            if sub and sub ~= "" then
                overrides[tostring(i)] = sub
            end
        end

        local col = ent:GetColor()
        local render_mode = ent:GetRenderMode() or 0

        db.materials[guid_str] = {
            entity_id = guid_str,
            skin = ent:GetSkin() or 0,
            materials_list = mats,
            submaterials = overrides,
            color = col and {col.r, col.g, col.b} or {255, 255, 255},
            alpha = col and col.a or 255,
            render_mode = render_mode
        }
    end
end
