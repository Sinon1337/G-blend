-- FrameDumper.lua  v11  "Export all bones in camera-relative coordinates"
--
-- Use ONLY wep.VModel and wep.Attachments — same sources as EntityRuntimeInspector,
-- but WITHOUT scanning the hands/player children (which drags in player body, worldmodels, etc.)
--
-- For each ARC9 attachment entity:
--   world_matrix : 16 numbers — Source Engine render-time world matrix
--   pos / ang    : local-space backup (WorldToLocal relative to ViewModel)
--   root_bone    : name of the model's root bone (used for skeletal parent bone matching)
--

return function(db, wep, vm)
    local ply = LocalPlayer()
    if not IsValid(vm) then vm = ply:GetViewModel() end
    if not IsValid(vm) then return end
    if not IsValid(wep) then return end

    local ref_pos = vm:GetPos()
    local ref_ang = vm:GetAngles()

    local function MatrixToTable(m)
        if not m then return nil end
        local t = {}
        for r = 1, 4 do for c = 1, 4 do t[#t+1] = m:GetField(r, c) end end
        return t
    end

    local vm_mat = vm:GetWorldTransformMatrix()

    local vm_bodygroups = {}
    if vm.GetBodyGroups then
        for _, bg in ipairs(vm:GetBodyGroups() or {}) do
            vm_bodygroups[bg.name] = vm:GetBodygroup(bg.id)
        end
    end

    db.framedump = {
        viewmodel = {
            model        = vm:GetModel(),
            world_matrix = MatrixToTable(vm_mat),
            bodygroups   = vm_bodygroups,
        },
        objects  = {},
        hands    = { model = nil, pos = {0,0,0}, ang = {0,0,0}, bones = {} },
        vm_bones = {},
    }

    -- ── Collect ONLY weapon attachment entities ───────────────────────────────
    local seen = {}

    local function CaptureEnt(ent, parent_bone, parent_guid)
        if seen[ent] then return end
        if not IsValid(ent) then return end
        local model = ent:GetModel()
        if not model or model == "" then return end
        seen[ent] = true

        local mat = ent:GetWorldTransformMatrix()
        local w_pos, w_ang
        if mat then
            w_pos = mat:GetTranslation()
            w_ang = mat:GetAngles()
        end
        if not w_pos then
            w_pos = ent:GetPos()
            w_ang = ent:GetAngles()
        end

        local l_pos, l_ang = WorldToLocal(w_pos, w_ang, ref_pos, ref_ang)

        local bones_data = {}
        if ent.GetBoneCount and ent:GetBoneCount() then
            ent:SetupBones()
            for i = 0, ent:GetBoneCount() - 1 do
                local bm = ent:GetBoneMatrix(i)
                if bm then
                    local b_pos = bm:GetTranslation()
                    local b_ang = bm:GetAngles()
                    local parent = ent:GetBoneParent(i)
                    
                    -- Always export bone pos/ang relative to the viewmodel camera!
                    local lp, la = WorldToLocal(b_pos, b_ang, ref_pos, ref_ang)
                    
                    local b_scl = bm:GetScale()
                    table.insert(bones_data, {
                        id = i, name = ent:GetBoneName(i),
                        parent = parent,
                        pos = { lp.x, lp.y, lp.z },
                        ang = { la.p, la.y, la.r },
                        scale = { b_scl.x, b_scl.y, b_scl.z },
                    })
                end
            end
        end

        local root_bone = nil
        if ent.GetBoneCount and ent:GetBoneCount() > 0 then
            root_bone = ent:GetBoneName(0)
        end

        local bodygroups = {}
        if ent.GetBodyGroups then
            for _, bg in ipairs(ent:GetBodyGroups() or {}) do
                bodygroups[bg.name] = ent:GetBodygroup(bg.id)
            end
        end

        table.insert(db.framedump.objects, {
            guid         = tostring(db.entity_to_guid and db.entity_to_guid[ent] or "?"),
            model        = model,
            class        = ent:GetClass(),
            skin         = ent:GetSkin() or 0,
            pos          = { l_pos.x, l_pos.y, l_pos.z },
            ang          = { l_ang.p, l_ang.y, l_ang.r },
            world_matrix = MatrixToTable(mat),
            bones        = bones_data,
            parent_bone  = parent_bone,
            parent_guid  = parent_guid,
            root_bone    = root_bone,
            bodygroups   = bodygroups,
        })
    end

    -- ARC9 first-person VModel parts
    if wep.VModel then
        for _, ent in pairs(wep.VModel) do
            if IsValid(ent) and not ent.NoDraw then
                CaptureEnt(ent, nil, "23")
            end
        end
    end

    -- ARC9 attachment slot entities
    local function CaptureSlots(slots, parent_guid)
        if not slots then return end
        for _, slot in pairs(slots) do
            if IsValid(slot.Ent) and not slot.Ent.NoDraw then
                CaptureEnt(slot.Ent, slot.Bone, parent_guid)
            end
            if slot.SubAttachments and IsValid(slot.Ent) then
                local my_guid = tostring(db.entity_to_guid and db.entity_to_guid[slot.Ent] or "?")
                CaptureSlots(slot.SubAttachments, my_guid)
            end
        end
    end

    if wep.Attachments then
        CaptureSlots(wep.Attachments, "23")
    end

    print("[FrameDumper v11] Exported " .. #db.framedump.objects .. " weapon entities")

    -- ── ViewModel bones ───────────────────────────────────────────────────────
    vm:SetupBones()
    for i = 0, (vm:GetBoneCount() or 0) - 1 do
        local bm = vm:GetBoneMatrix(i)
        if bm then
            local b_pos = bm:GetTranslation()
            local b_ang = bm:GetAngles()
            local parent = vm:GetBoneParent(i)
            
            -- Always export bone pos/ang relative to the viewmodel camera!
            local lp, la = WorldToLocal(b_pos, b_ang, ref_pos, ref_ang)
            
            local b_scl = bm:GetScale()
            table.insert(db.framedump.vm_bones, {
                id = i, name = vm:GetBoneName(i),
                parent = parent,
                pos = { lp.x, lp.y, lp.z },
                ang = { la.p, la.y, la.r },
                scale = { b_scl.x, b_scl.y, b_scl.z },
            })
        end
    end

    -- ── Hands ─────────────────────────────────────────────────────────────────
    local hands = ply:GetHands()
    if not IsValid(hands) then hands = ply:GetViewModel(1) end
    if IsValid(hands) then
        db.framedump.hands.model = hands:GetModel()
        db.framedump.hands.pos   = { 0, 0, 0 }
        db.framedump.hands.ang   = { 0, 0, 0 }

        hands:SetupBones()
        for i = 0, (hands:GetBoneCount() or 0) - 1 do
            local bm = hands:GetBoneMatrix(i)
            if bm then
                local b_pos = bm:GetTranslation()
                local b_ang = bm:GetAngles()
                local parent = hands:GetBoneParent(i)
                
                -- Always export bone pos/ang relative to the viewmodel camera!
                local lp, la = WorldToLocal(b_pos, b_ang, ref_pos, ref_ang)
                
                local b_scl = bm:GetScale()
                table.insert(db.framedump.hands.bones, {
                    id = i, name = hands:GetBoneName(i),
                    parent = parent,
                    pos = { lp.x, lp.y, lp.z },
                    ang = { la.p, la.y, la.r },
                    scale = { b_scl.x, b_scl.y, b_scl.z },
                })
            end
        end
    end
end
