ARC9_CAPTURE = ARC9_CAPTURE or {}
ARC9_CAPTURE.Registry = ARC9_CAPTURE.Registry or {}

-- 1. Registry
-- We track all newly created clientside models. 
-- In ARC9, attachments are usually C_BaseAnimating or standard ClientsideModel.
hook.Add("OnEntityCreated", "ARC9_RuntimeCapture_Registry", function(ent)
    if not IsValid(ent) then return end
    -- Wait 1 frame so entity class is fully assigned
    timer.Simple(0, function()
        if not IsValid(ent) then return end
        local class = ent:GetClass()
        if class == "class C_BaseAnimating" or class == "class C_HL2MPRagdoll" or class == "viewmodel" or class == "gmod_hands" then
            ARC9_CAPTURE.Registry[ent] = true
        end
    end)
end)

-- Clean up registry periodically to avoid memory leaks with dead entities
timer.Create("ARC9_Capture_Registry_Cleanup", 5, 0, function()
    for ent, _ in pairs(ARC9_CAPTURE.Registry) do
        if not IsValid(ent) then
            ARC9_CAPTURE.Registry[ent] = nil
        end
    end
end)

-- 2. State
ARC9_CAPTURE.PendingCapture = false

-- 3. Include Modules
include("capture_matrix.lua")
include("capture_materials.lua")
include("capture_skeleton.lua")
include("capture_entities.lua")
include("capture_frame.lua")
include("exporter.lua")

-- 4. Hook for capture trigger
hook.Add("PostDrawViewModel", "ARC9_Runtime_Capture_Hook", function(vm, ply, weapon)
    if not ARC9_CAPTURE.PendingCapture then return end
    ARC9_CAPTURE.PendingCapture = false
    
    print("[ARC9 Capture] Intercepted PostDrawViewModel! Extracting frame...")
    ARC9_CAPTURE.ExportFrame(vm, weapon, ply)
end)

concommand.Add("gmod_scene_export_arc9", function()
    print("[ARC9 Capture] Requested frame capture... Waiting for PostDrawViewModel")
    ARC9_CAPTURE.PendingCapture = true
end)
