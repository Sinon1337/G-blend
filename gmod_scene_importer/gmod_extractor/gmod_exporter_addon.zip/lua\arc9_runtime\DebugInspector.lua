-- DebugInspector.lua
-- Captures runtime diagnostic logs, counts, timings, and warnings.

return function(db, wep, vm)
    db.debug = {
        warnings = {},
        timings = {},
        objects_found = 0,
        resources_found = 0
    }

    local start_time = SysTime()

    -- Timings and warnings logic
    for guid_str, ent in pairs(db.guid_to_entity) do
        db.debug.objects_found = db.debug.objects_found + 1
        
        local mdl = ent:GetModel()
        if not mdl or mdl == "" or mdl == "models/error.mdl" then
            table.insert(db.debug.warnings, "Entity [" .. guid_str .. "] has missing or invalid model.")
        end
    end

    for _, _ in pairs(db.resources) do
        db.debug.resources_found = db.debug.resources_found + 1
    end

    db.debug.timings.total_inspector_time_ms = math.Round((SysTime() - start_time) * 1000, 3)
end
