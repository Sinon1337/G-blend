-- AnimationInspector.lua
-- Captures the active animation sequence, cycle, playback rate, and pose parameters.

return function(db, wep, vm)
    db.animations = {}

    for guid_str, ent in pairs(db.guid_to_entity) do
        local pose_params = {}
        local count = ent:GetNumPoseParameters() or 0
        for i = 0, count - 1 do
            local name = ent:GetPoseParameterName(i)
            if name and name ~= "" then
                pose_params[name] = ent:GetPoseParameter(i) or 0.0
            end
        end

        db.animations[guid_str] = {
            entity_id = guid_str,
            sequence = ent:GetSequence() or 0,
            sequence_name = ent:GetSequenceName(ent:GetSequence() or 0) or "unknown",
            cycle = ent:GetCycle() or 0,
            playback_rate = ent:GetPlaybackRate() or 0,
            pose_parameters = pose_params
        }
    end
end
