-- WeaponRuntimeInspector.lua
-- Discovers active weapon, viewmodel, and player hands.

return function(db, wep, vm)
    db.metadata = {
        exporter_version = "6.0",
        export_time = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        weapon_class = wep:GetClass(),
        weapon_printname = wep:GetPrintName() or wep:GetClass(),
        base = wep.Base or "unknown"
    }
end
