ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.GetCandidates(vm, weapon, hands)
    local candidates = {}
    
    local function addEnt(ent)
        if IsValid(ent) and ent:GetModel() then
            candidates[ent] = true
        end
    end
    
    -- Core
    addEnt(vm)
    addEnt(hands)
    addEnt(weapon)
    
    if IsValid(vm) then
        for _, child in pairs(vm:GetChildren()) do
            addEnt(child)
        end
    end
    
    if IsValid(weapon) then
        for _, child in pairs(weapon:GetChildren()) do
            addEnt(child)
        end
    end
    
    -- Registry
    for ent, _ in pairs(ARC9_CAPTURE.Registry) do
        if IsValid(ent) then
            addEnt(ent)
        end
    end
    
    return candidates
end
