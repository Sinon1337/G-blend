--[[
    AdvDupe2 JSON Export Command + Live Scene Capture
    
    Two commands:
    1. advdupe2_export_to_json <filename>   - Export from saved AdvDupe2 .txt file
    2. gmod_scene_export_live               - Capture LIVE scene state from all server entities
    
    Output: data/gmod_scene_export.json
]]

if not SERVER then return end

-- ============================================================
-- SHARED UTILITIES
-- ============================================================

local ModelDataCache = {}

-- Spawn temp prop to get model metadata (materials, bone names, bodygroup names)
local function GetModelData(modelPath, physObjs)
    if not modelPath then return {mats={}, phys_bones={}, num_bodygroups=0, bodygroup_names={}} end
    if ModelDataCache[modelPath] then return ModelDataCache[modelPath] end
    
    local p = ents.Create("prop_dynamic")
    if not IsValid(p) then return {mats={}, phys_bones={}, num_bodygroups=0, bodygroup_names={}} end
    
    p:SetModel(modelPath)
    local mats = p:GetMaterials() or {}
    local phys_bones = {}
    
    local num_bg = p:GetNumBodyGroups() or 0
    local bg_names = {}
    for i = 0, num_bg - 1 do
        bg_names[i] = p:GetBodygroupName(i)
    end
    
    if physObjs then
        for physID, _ in pairs(physObjs) do
            local bone_idx = p:TranslatePhysBoneToBone(physID)
            if bone_idx then
                local bName = p:GetBoneName(bone_idx)
                if bName then
                    phys_bones[physID] = bName
                end
            end
        end
    end
    
    p:Remove()
    
    local res = {mats = mats, phys_bones = phys_bones, num_bodygroups = num_bg, bodygroup_names = bg_names}
    ModelDataCache[modelPath] = res
    return res
end

-- Decode compressed BodyG float -> {[0]=val0, [1]=val1, ...}
local function DecodeBodyG(bodyG, numGroups)
    if not bodyG or bodyG == 0 then return {} end
    local groups = {}
    local val = math.floor(bodyG)
    for i = 0, (numGroups or 10) - 1 do
        local digit = val % 10
        groups[tostring(i)] = digit
        val = math.floor(val / 10)
        if val == 0 then break end
    end
    return groups
end

-- Normalize submaterials: {["0"]="path"} or {[0]="path"} -> {[0]="path", ...}
local function NormalizeSubMaterials(raw)
    if not raw then return {} end
    local out = {}
    for k, v in pairs(raw) do
        local idx = tostring(k)
        if v and v ~= "" then
            out[idx] = v
        end
    end
    return out
end

local function PlayerPrint(ply, msg)
    if IsValid(ply) then
        ply:ChatPrint(msg)
    else
        print(msg)
    end
end

-- Get scale from any entity supporting custom resizers
-- Get scale from any entity supporting custom resizers
local function GetUniversalScale(ent)
    local scaleVec = Vector(1, 1, 1)
    if not IsValid(ent) then return {1, 1, 1} end

    -- Check if this is a child of a prop_effect (for effect resizers)
    local parent = ent:GetParent()
    if IsValid(parent) and parent:GetClass() == "prop_effect" then
        if parent.scalevec then
            scaleVec = parent.scalevec
        elseif parent.effectresizedata and parent.effectresizedata[2] then
            scaleVec = parent.effectresizedata[2]
        end
    end

    -- Direct custom scale variables on the entity
    if ent.scalevec and type(ent.scalevec) == "Vector" then
        scaleVec = ent.scalevec
    elseif ent.effectresizedata and ent.effectresizedata[2] and type(ent.effectresizedata[2]) == "Vector" then
        scaleVec = ent.effectresizedata[2]
    end

    -- 1. ManipulateBoneScale (Collision Resizer, Effect Resizer, standard resizers)
    local bs = ent:GetManipulateBoneScale(0)
    if bs and bs.x > 0.001 and bs.y > 0.001 and bs.z > 0.001 then
        scaleVec = Vector(bs.x, bs.y, bs.z)
    end

    -- 2. Networked Vector (e.g. AdvPropResizer / other tools)
    local nwv = ent:GetNWVector("Scale")
    if nwv and nwv:LengthSqr() > 0.001 then
        scaleVec = nwv
    else
        local nwv2 = ent:GetNWVector("PropScale")
        if nwv2 and nwv2:LengthSqr() > 0.001 then
            scaleVec = nwv2
        end
    end

    -- 3. Custom Lua object variables
    if ent.ModelScale and type(ent.ModelScale) == "Vector" then
        scaleVec = ent.ModelScale
    elseif ent.Scale and type(ent.Scale) == "Vector" then
        scaleVec = ent.Scale
    elseif ent.TargetScale and type(ent.TargetScale) == "Vector" then
        scaleVec = ent.TargetScale
    end

    -- Multiply by the global model scale
    local ms = ent:GetModelScale() or 1
    return {scaleVec.x * ms, scaleVec.y * ms, scaleVec.z * ms}
end

-- Get scale from AdvDupe2 entity data
local function GetDupeUniversalScale(entData)
    local scaleVec = {1, 1, 1}
    local ms = 1
    
    -- Check Effect Resizer duplicator mods
    if entData.EntityMods then
        local resizerData = entData.EntityMods.Effect_Resizer_DataDupe or entData.EntityMods.collision_resizer
        if resizerData then
            if resizerData[1] then
                ms = resizerData[1]
            end
            if resizerData[2] then
                local s = resizerData[2]
                scaleVec = {s.x or s[1] or 1, s.y or s[2] or 1, s.z or s[3] or 1}
            end
        end
    end

    if entData.ModelScale then
        if type(entData.ModelScale) == "number" then
            ms = entData.ModelScale
        elseif type(entData.ModelScale) == "table" then
            local s = entData.ModelScale
            scaleVec = {s.x or s[1] or 1, s.y or s[2] or 1, s.z or s[3] or 1}
        end
    end

    if entData.BoneManip and entData.BoneManip[0] and entData.BoneManip[0].s then
        local s = entData.BoneManip[0].s
        scaleVec = {s.x or s[1] or 1, s.y or s[2] or 1, s.z or s[3] or 1}
    end

    if entData.dt then
        local dtScale = entData.dt.Scale or entData.dt.ModelScale or entData.dt.VectorScale
        if dtScale then
            if type(dtScale) == "number" then
                ms = dtScale
            elseif type(dtScale) == "table" then
                scaleVec = {dtScale.x or dtScale[1] or 1, dtScale.y or dtScale[2] or 1, dtScale.z or dtScale[3] or 1}
            end
        end
    end

    if entData.Scale then
        if type(entData.Scale) == "number" then
            ms = entData.Scale
        elseif type(entData.Scale) == "table" then
            scaleVec = {entData.Scale.x or entData.Scale[1] or 1, entData.Scale.y or entData.Scale[2] or 1, entData.Scale.z or entData.Scale[3] or 1}
        elseif type(entData.Scale) == "Vector" then
            scaleVec = {entData.Scale.x, entData.Scale.y, entData.Scale.z}
        end
    end

    return {scaleVec[1] * ms, scaleVec[2] * ms, scaleVec[3] * ms}
end

-- Build JSON from AdvDupe2 entity table
local function BuildExportFromDupe(dupeTbl, info)
    local exportData = {
        version = 2.0,
        type = "live_scene",
        export_mode = "advdupe2",
        scene_name = info and info.name or "dupe",
        objects = {},
        camera = nil,
        meta = {
            map = game.GetMap(),
        },
    }

    for k, entData in pairs(dupeTbl.Entities or {}) do
        local pos = nil
        local ang = nil

        local function checkPhys(phys)
            if not phys then return false end
            local p = phys.Pos or phys.LocalPos
            local a = phys.Angle or phys.LocalAngle
            if p and a then
                pos = p
                ang = a
                return true
            end
            return false
        end

        if entData.PhysicsObjects then
            if not checkPhys(entData.PhysicsObjects[0]) then
                checkPhys(entData.PhysicsObjects[1])
            end
            if not pos then
                for _, phys in pairs(entData.PhysicsObjects) do
                    if checkPhys(phys) then break end
                end
            end
        end

        if not pos then
            pos = entData.Pos or entData.LocalPos
            ang = entData.Angle or entData.LocalAngle
        end

        if not pos then
            print("[AdvDupe2-JSON] Warning: NO POSITION for " .. k .. " (" .. (entData.Model or "?") .. ")")
            pos = Vector(0, 0, 0)
        end
        ang = ang or Angle(0, 0, 0)

        local physObjKeys = {}
        if entData.PhysicsObjects then
            for id, _ in pairs(entData.PhysicsObjects) do
                physObjKeys[id] = true
            end
        end

        local modelData = GetModelData(entData.Model, physObjKeys)

        local decodedBodygroups = {}
        if entData.BodyGroups and next(entData.BodyGroups) then
            for k2, v2 in pairs(entData.BodyGroups) do
                local idx = tonumber(k2)
                if idx and v2 and v2 ~= 0 then
                    decodedBodygroups[idx] = v2
                end
            end
        elseif entData.BodyG and entData.BodyG ~= 0 then
            decodedBodygroups = DecodeBodyG(entData.BodyG, modelData.num_bodygroups)
        end

        local scaleVec = GetDupeUniversalScale(entData)

        local isBoneMerge = false
        if entData.Parent and entData.Parent ~= 0 then
            if entData.Effects and bit.band(entData.Effects, 4) ~= 0 then
                isBoneMerge = true
            elseif entData.EntityMods and entData.EntityMods.bonemerge then
                isBoneMerge = true
            end
        end

        local obj = {
            id = k,
            parent_id = entData.Parent,
            is_bonemerge = isBoneMerge,
            intrinsic_materials = modelData.mats,
            submaterials = NormalizeSubMaterials(entData.SubMaterials),
            name = "Entity_" .. k .. "_" .. (entData.Class or "prop"),
            class = entData.Class,
            model = entData.Model,
            scale = scaleVec,
            skin = entData.Skin or 0,
            bodygroups = decodedBodygroups,
            bodygroup_names = modelData.bodygroup_names,
            material = entData.Material,
            position = {pos.x, pos.y, pos.z},
            rotation_euler = {ang.p, ang.y, ang.r},
            bones = {},
        }

        if entData.PhysicsObjects then
            for boneID, physData in pairs(entData.PhysicsObjects) do
                local bPos = physData.Pos or physData.LocalPos
                local bAng = physData.Angle or physData.LocalAngle
                local bName = modelData.phys_bones[boneID]

                if bPos and bAng then
                    table.insert(obj.bones, {
                        id = boneID,
                        name = bName,
                        pos = {bPos.x, bPos.y, bPos.z},
                        angle = {bAng.p, bAng.y, bAng.r},
                    })
                end
            end
        end

        if entData.Class == "gmod_cameraprop" or entData.Class == "hl_camera" or entData.Class == "gmod_rtcamera" then
            local fovVal = entData.fov or (entData.dt and entData.dt.FOV) or 75
            local isOn = (entData.dt and entData.dt.On) or false
            obj.fov = fovVal
            obj.active = isOn
            exportData.camera = {
                fov = fovVal,
                active = isOn,
                position = obj.position,
                rotation_euler = obj.rotation_euler,
            }
        end

        table.insert(exportData.objects, obj)
    end

    exportData.meta.count = #exportData.objects

    local centroid = SceneExport.ComputeCentroidFromObjects(exportData.objects)
    SceneExport.ApplyCentroid(exportData.objects, centroid)

    if exportData.camera and exportData.camera.position then
        exportData.camera.position = {
            exportData.camera.position[1] - centroid.x,
            exportData.camera.position[2] - centroid.y,
            exportData.camera.position[3] - centroid.z,
        }
    end

    exportData.meta.centroid = {x = centroid.x, y = centroid.y, z = centroid.z}

    return exportData
end

-- ============================================================
-- COMMAND 1: AdvDupe2 File Export (saved dupe -> JSON)
-- ============================================================

concommand.Add("advdupe2_export_to_json", function(ply, cmd, args)
    if #args < 1 then
        print("[AdvDupe2-JSON] Usage: advdupe2_export_to_json <filename> [outname]")
        return
    end

    local name = args[1]
    if not string.EndsWith(name, ".txt") then
        name = name .. ".txt"
    end

    local path = "advdupe2/" .. name
    if not file.Exists(path, "DATA") then
        print("[AdvDupe2-JSON] Error: File not found: " .. path)
        return
    end

    print("[AdvDupe2-JSON] Reading: " .. path)
    local dupeString = file.Read(path, "DATA")

    if not AdvDupe2 or not AdvDupe2.Decode then
        print("[AdvDupe2-JSON] Error: AdvDupe2 module not initialized.")
        return
    end

    local success, dupeTbl, info = AdvDupe2.Decode(dupeString)
    if not success then
        print("[AdvDupe2-JSON] Error: Failed to decode dupe. " .. tostring(dupeTbl))
        return
    end

    print("[AdvDupe2-JSON] Processing " .. table.Count(dupeTbl.Entities) .. " entities...")
    local exportData = BuildExportFromDupe(dupeTbl, info)
    local outName = args[2] or "gmod_scene_dupe.json"
    SceneExport.WriteJSON(exportData, outName)
end)

-- ============================================================
-- COMMAND 2: AdvDupe2 Clipboard Export (after area copy / right-click copy)
-- ============================================================

concommand.Add("advdupe2_export_clipboard", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply.AdvDupe2 or not ply.AdvDupe2.Entities or next(ply.AdvDupe2.Entities) == nil then
        PlayerPrint(ply, "[AdvDupe2-JSON] Clipboard is empty. Copy something with AdvDupe2 first.")
        return
    end

    local dupeTbl = {
        Entities = ply.AdvDupe2.Entities,
        Constraints = ply.AdvDupe2.Constraints,
        HeadEnt = ply.AdvDupe2.HeadEnt,
    }

    print("[AdvDupe2-JSON] Exporting clipboard (" .. table.Count(dupeTbl.Entities) .. " entities)...")
    local exportData = BuildExportFromDupe(dupeTbl, {name = "clipboard"})
    local outName = args[1] or "gmod_scene_dupe.json"
    SceneExport.WriteJSON(exportData, outName)
    PlayerPrint(ply, "[AdvDupe2-JSON] Exported clipboard to garrysmod/data/gmod_scene_export/" .. outName)
end)

print("[SceneExport] Server commands: advdupe2_export_to_json, advdupe2_export_clipboard")

-- ============================================================
-- NET BRIDGE: client console -> server export
-- ============================================================
util.AddNetworkString("SceneExport_Dupe")
util.AddNetworkString("SceneExport_Clipboard")

net.Receive("SceneExport_Dupe", function(len, ply)
    if IsValid(ply) and not ply:IsListenServerHost() then return end
    local filename = net.ReadString()
    RunConsoleCommand("advdupe2_export_to_json", filename)
end)

net.Receive("SceneExport_Clipboard", function(len, ply)
    if IsValid(ply) and not ply:IsListenServerHost() then return end
    local outName = net.ReadString()
    if outName == "" then outName = "gmod_scene_dupe.json" end
    RunConsoleCommand("advdupe2_export_clipboard", outName)
end)
