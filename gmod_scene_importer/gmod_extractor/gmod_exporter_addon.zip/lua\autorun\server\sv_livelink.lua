-- sv_livelink.lua
-- Server-side synchronization for GMod-Blender Live Link
-- Runs on GMod Dedicated Server, allowing bypass of client-side loopback blocks
--

AddCSLuaFile("autorun/client/cl_arc9_runtime_capture.lua")
AddCSLuaFile("arc9_runtime_capture/init.lua")
AddCSLuaFile("arc9_runtime_capture/capture_matrix.lua")
AddCSLuaFile("arc9_runtime_capture/capture_materials.lua")
AddCSLuaFile("arc9_runtime_capture/capture_skeleton.lua")
AddCSLuaFile("arc9_runtime_capture/capture_entities.lua")
AddCSLuaFile("arc9_runtime_capture/capture_frame.lua")
AddCSLuaFile("arc9_runtime_capture/exporter.lua")
AddCSLuaFile("arc9_runtime_capture/capture_registry.lua")

CreateConVar("gmod_livelink_host", "127.0.0.1", FCVAR_ARCHIVE, "IP/Host for Blender Live Link HTTP Server")
CreateConVar("gmod_livelink_port", "8000", FCVAR_ARCHIVE, "Port for Blender Live Link HTTP Server")
CreateConVar("gmod_livelink_interval", "0.05", FCVAR_ARCHIVE, "Sync interval in seconds (default 0.05 = 20hz)")

local gmod_livelink_running = false
local operator_ent = nil
local next_sync_time = 0
local sync_interval = 0.03 -- Fallback/default interval
local last_sent_entities = {}
local is_sending_update = false
local is_polling = false
local consecutive_failures = 0
local player_grabbed_ents = player_grabbed_ents or {}
local last_bone_states = {} -- Track last bone states for differential updates

hook.Add("PhysgunPickup", "GModLiveLink_PhysgunPickup", function(ply, ent)
    if IsValid(ply) and IsValid(ent) then
        player_grabbed_ents[ply:SteamID64()] = ent:EntIndex()
    end
end)

hook.Add("PhysgunDrop", "GModLiveLink_PhysgunDrop", function(ply, ent)
    if IsValid(ply) then
        player_grabbed_ents[ply:SteamID64()] = nil
    end
end)

local function SetEntityPhysicsFrozen(ent, frozen)
    if not IsValid(ent) then return end
    
    local count = ent:GetPhysicsObjectCount()
    if count and count > 1 then
        -- Ragdoll case (loop all physics objects)
        for i = 0, count - 1 do
            local phys = ent:GetPhysicsObjectNum(i)
            if IsValid(phys) then
                phys:EnableMotion(not frozen)
                if not frozen then
                    phys:Wake()
                end
            end
        end
    else
        -- Single prop case
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(not frozen)
            if not frozen then
                phys:Wake()
            end
        end
    end
end

local function IsSyncableEntity(ent)
    if not IsValid(ent) then return false end
    if ent:IsPlayer() then return false end
    
    local cls = ent:GetClass()
    if cls == "worldspawn" or cls == "viewmodel" then return false end
    
    -- Skip weapons currently held by players
    if ent:IsWeapon() and IsValid(ent:GetOwner()) and ent:GetOwner():IsPlayer() then
        return false
    end
    
    local mdl = ent:GetModel()
    if not mdl or mdl == "" or string.sub(mdl, -4) ~= ".mdl" then
        return false
    end
    
    return true
end

local function GetActualBoneTransform(ent, i)
    local cls = ent:GetClass()
    if cls == "prop_ragdoll" then
        local phys_bone = ent:TranslateBoneToPhysBone(i)
        if phys_bone and phys_bone >= 0 then
            local count = ent:GetPhysicsObjectCount()
            if count and phys_bone < count then
                local phys = ent:GetPhysicsObjectNum(phys_bone)
                if IsValid(phys) then
                    return phys:GetPos(), phys:GetAngles()
                end
            end
        end
    end
    return ent:GetBonePosition(i)
end

local function SendServerPlayerUpdate()
    local plys = player.GetAll()
    if #plys == 0 then return end

    local host = GetConVar("gmod_livelink_host"):GetString()
    local port = GetConVar("gmod_livelink_port"):GetInt()

    -- Gather all players
    local playersList = {}
    for _, ply in ipairs(plys) do
        if IsValid(ply) then
            local pos = ply:EyePos()
            local ang = ply:EyeAngles()
            
            local bones = nil
            if ply:GetBoneCount() and ply:GetBoneCount() > 1 then
                bones = {}
                for i = 0, ply:GetBoneCount() - 1 do
                    pcall(function()
                        local name = ply:GetBoneName(i)
                        local bpos, bang = ply:GetBonePosition(i)
                        if bpos and bang then
                            local scaleVec = ply:GetManipulateBoneScale(i)
                            table.insert(bones, {
                                name = name,
                                pos = { bpos.x, bpos.y, bpos.z },
                                ang = { bang.p, bang.y, bang.r },
                                scale = { scaleVec.x, scaleVec.y, scaleVec.z }
                            })
                        end
                    end)
                end
            end
            
            local activeWep = ply:GetActiveWeapon()
            local weaponData = nil
            if IsValid(activeWep) then
                weaponData = {
                    class = activeWep:GetClass(),
                    model = activeWep:GetModel(),
                    id = activeWep:EntIndex()
                }
            end
            
            local grabbedEntId = player_grabbed_ents[ply:SteamID64()]
            if grabbedEntId and not IsValid(Entity(grabbedEntId)) then
                player_grabbed_ents[ply:SteamID64()] = nil
                grabbedEntId = nil
            end
            
            local plyCol = ply:GetWeaponColor() or Vector(0, 1, 1)
            local physColor = { plyCol.x * 255, plyCol.y * 255, plyCol.z * 255 }
            
            table.insert(playersList, {
                steamid = ply:SteamID64(),
                name = ply:Name(),
                nick = ply:Nick(),
                pos = { pos.x, pos.y, pos.z },
                ang = { ang.p, ang.y, ang.r },
                bones = bones,
                model = ply:GetModel(),
                weapon = weaponData,
                holding_entity_id = grabbedEntId,
                physgun_color = physColor,
                model_scale = math.Clamp(ply:GetModelScale() or 1.0, 0.1, 10.0),
                fov = ply:GetFOV(),
                hp = ply:Health(),
                hp_max = ply:GetMaxHealth(),
                armor = ply:Armor(),
                alive = ply:Alive(),
                team = team.GetName(ply:Team()),
                ping = ply:Ping()
            })
        end
    end

    -- Gather all valid 3D entities in the game (props, ragdolls, NPCs, effects, custom entities, etc.)
    local propsList = {}
    local syncEnts = {}
    for _, ent in ipairs(ents.GetAll()) do
        if IsSyncableEntity(ent) then
            table.insert(syncEnts, ent)
        end
    end
    
    for _, ent in ipairs(syncEnts) do
        if IsValid(ent) and ent:GetModel() then
            local ePos = ent:GetPos()
            local eAng = ent:GetAngles()
            local phys = ent:GetPhysicsObject()
            
            local isFrozen = false
            local isAsleep = false
            if IsValid(phys) then
                isFrozen = not phys:IsMotionEnabled()
                isAsleep = phys:IsAsleep()
            end
            
            local cls = ent:GetClass()
            if cls == "prop_ragdoll" then
                isAsleep = true
                local count = ent:GetPhysicsObjectCount() or 0
                for i = 0, count - 1 do
                    local p = ent:GetPhysicsObjectNum(i)
                    if IsValid(p) and not p:IsAsleep() then
                        isAsleep = false
                        break
                    end
                end
            end
            
            local entId = ent:EntIndex()
            local lastState = last_sent_entities[entId]
            local shouldSend = false
            
            local currentSkin = ent:GetSkin()
            local currentScale = ent:GetModelScale()
            local isJittering = false
            
            if lastState then
                local dist = ePos:Distance(lastState.pos)
                local jitterTime = lastState.jitterTime or 0
                local jitterStartPos = lastState.jitterStartPos
                
                if dist > 0.001 then
                    if dist < 0.3 then
                        if not jitterStartPos then
                            jitterStartPos = lastState.pos
                        end
                        local drift = ePos:Distance(jitterStartPos)
                        if drift > 3.0 then
                            jitterTime = 0
                            jitterStartPos = nil
                        else
                            jitterTime = jitterTime + sync_interval
                        end
                    else
                        jitterTime = 0
                        jitterStartPos = nil
                    end
                end
                
                lastState.jitterTime = jitterTime
                lastState.jitterStartPos = jitterStartPos
                
                if jitterTime > 3.0 then
                    isJittering = true
                end
            end
            
            if not lastState then
                shouldSend = true
            else
                local posDiff = ePos:DistToSqr(lastState.pos) > 0.01
                local angDiff = math.abs(eAng.p - lastState.ang.p) > 0.1 or
                                math.abs(eAng.y - lastState.ang.y) > 0.1 or
                                math.abs(eAng.r - lastState.ang.r) > 0.1
                
                local frozenChanged = (isFrozen ~= lastState.isFrozen)
                local sleepChanged = (isAsleep ~= lastState.isAsleep)
                local skinChanged = (currentSkin ~= lastState.skin)
                local scaleChanged = (currentScale ~= lastState.scale)
                
                if isJittering then
                    shouldSend = false
                elseif posDiff or angDiff or frozenChanged or sleepChanged or skinChanged or scaleChanged or (not isAsleep and not isFrozen) then
                    shouldSend = true
                end
            end
            
            if shouldSend then
                local saveJitterTime = lastState and lastState.jitterTime or 0
                local saveJitterStart = lastState and lastState.jitterStartPos or nil
                last_sent_entities[entId] = {
                    pos = ePos,
                    ang = eAng,
                    isFrozen = isFrozen,
                    isAsleep = isAsleep,
                    skin = currentSkin,
                    scale = currentScale,
                    jitterTime = saveJitterTime,
                    jitterStartPos = saveJitterStart
                }
                
                local bgs = {}
                for bg_id = 0, ent:GetNumBodyGroups() - 1 do
                    bgs[tostring(bg_id)] = ent:GetBodygroup(bg_id)
                end
                
                local bones = nil
                local isMultiBone = cls == "prop_ragdoll"
                    or string.StartWith(cls, "npc_")
                    or string.StartWith(cls, "prop_vehicle")
                    or string.StartWith(cls, "gmod_sent_vehicle")
                    or string.StartWith(cls, "vehicle_")
                
                if isMultiBone then
                    local boneCount = ent:GetBoneCount() or 0
                    if boneCount > 1 then
                        bones = {}
                        local entityKey = tostring(entId)
                        last_bone_states[entityKey] = last_bone_states[entityKey] or {}
                        
                        for i = 0, boneCount - 1 do
                            pcall(function()
                                local boneName = ent:GetBoneName(i)
                                local bpos, bang = GetActualBoneTransform(ent, i)
                                if bpos and bang then
                                    local scaleVec = ent:GetManipulateBoneScale(i)
                                    
                                    -- Differential update: only send if bone changed significantly
                                    local lastState = last_bone_states[entityKey][i]
                                    local posChanged = not lastState or bpos:Distance(lastState.pos) > 0.01
                                    local angChanged = not lastState or 
                                        math.abs(bang.p - lastState.ang.p) > 1 or
                                        math.abs(bang.y - lastState.ang.y) > 1 or
                                        math.abs(bang.r - lastState.ang.r) > 1
                                    local scaleChanged = not lastState or
                                        math.abs(scaleVec.x - lastState.scale.x) > 0.01 or
                                        math.abs(scaleVec.y - lastState.scale.y) > 0.01 or
                                        math.abs(scaleVec.z - lastState.scale.z) > 0.01
                                    
                                    if posChanged or angChanged or scaleChanged then
                                        table.insert(bones, {
                                            name = boneName,
                                            pos = { bpos.x, bpos.y, bpos.z },
                                            ang = { bang.p, bang.y, bang.r },
                                            scale = { scaleVec.x, scaleVec.y, scaleVec.z }
                                        })
                                        
                                        -- Update last state
                                        last_bone_states[entityKey][i] = {
                                            pos = bpos,
                                            ang = bang,
                                            scale = scaleVec
                                        }
                                    end
                                end
                            end)
                        end
                    end
                end
                
                local mins = ent:OBBMins()
                local maxs = ent:OBBMaxs()
                table.insert(propsList, {
                    gmod_id = entId,
                    class = cls,
                    model = ent:GetModel(),
                    pos = { ePos.x, ePos.y, ePos.z },
                    ang = { eAng.p, eAng.y, eAng.r },
                    frozen = isFrozen,
                    skin = currentSkin,
                    bodygroups = bgs,
                    bones = bones,
                    model_scale = currentScale,
                    obb_mins = { mins.x, mins.y, mins.z },
                    obb_maxs = { maxs.x, maxs.y, maxs.z }
                })
            end
        end
    end

    if is_sending_update then return end

    -- Only send if we have actual updates to report, or on initial connection setup
    if #playersList == 0 and #propsList == 0 and RealTime() > 3.0 then
        return
    end

    is_sending_update = true
    HTTP({
        url = "http://" .. host .. ":" .. port .. "/update",
        method = "POST",
        headers = { ["Content-Type"] = "application/json" },
        body = util.TableToJSON({
            type = "world_state",
            map = game.GetMap(),
            players = playersList,
            props = propsList
        }),
        success = function(code, body)
            is_sending_update = false
            consecutive_failures = 0
        end,
        failed = function(err)
            is_sending_update = false
            consecutive_failures = consecutive_failures + 1
            if consecutive_failures >= 15 and gmod_livelink_running then
                gmod_livelink_running = false
                hook.Remove("Think", "GMod_LiveLink_Server_Sync")
                print("[GModLiveLink] Blender server connection lost (15 consecutive failures). Live Link paused to prevent server lag.")
            end
        end
    })
end

local function PollBlenderServerUpdates()
    if is_polling then return end
    is_polling = true

    local host = GetConVar("gmod_livelink_host"):GetString()
    local port = GetConVar("gmod_livelink_port"):GetInt()

    -- Poll changes made inside Blender
    HTTP({
        url = "http://" .. host .. ":" .. port .. "/poll",
        method = "GET",
        success = function(code, body)
            is_polling = false
            consecutive_failures = 0
            if code == 200 then
                local updates = util.JSONToTable(body)
                if updates and #updates > 0 then
                    for _, packet in ipairs(updates) do
                        if packet.type == "spawn_operator" then
                            local posTable = packet.pos
                            local angTable = packet.ang
                            local spawnPos = Vector(posTable[1], posTable[2], posTable[3])
                            local spawnAng = Angle(angTable[1], angTable[2], angTable[3])
                            
                            if IsValid(operator_ent) then
                                operator_ent:Remove()
                            end
                            
                            operator_ent = ents.Create("prop_dynamic")
                            operator_ent:SetModel("models/maxofs2d/camera.mdl")
                            operator_ent:SetPos(spawnPos)
                            operator_ent:SetAngles(spawnAng)
                            operator_ent:Spawn()
                            
                            operator_ent:SetRenderMode(RENDERMODE_TRANSCOLOR)
                            operator_ent:SetColor(Color(0, 255, 0, 220))
                            operator_ent:SetSolid(SOLID_NONE)
                            
                            print("[GModLiveLink] Blender Operator Camera model spawned!")
                        elseif packet.type == "player_teleport" then
                            local posTable = packet.pos
                            local angTable = packet.ang
                            local newPos = Vector(posTable[1], posTable[2], posTable[3])
                            local newAng = Angle(angTable[1], angTable[2], angTable[3])
                            
                            -- Find target player by SteamID or name
                            local targetPly = nil
                            if packet.steamid then
                                for _, ply in ipairs(player.GetAll()) do
                                    if ply:SteamID64() == tostring(packet.steamid) then
                                        targetPly = ply
                                        break
                                    end
                                end
                            end
                            if not targetPly and packet.name then
                                for _, ply in ipairs(player.GetAll()) do
                                    if ply:Name() == packet.name then
                                        targetPly = ply
                                        break
                                    end
                                end
                            end
                            
                            if targetPly then
                                if targetPly:GetMoveType() ~= MOVETYPE_NOCLIP then
                                    targetPly:SetMoveType(MOVETYPE_NOCLIP)
                                    print("[GModLiveLink] Enabling NOCLIP for player " .. targetPly:Name() .. " due to Blender control.")
                                end
                                targetPly:SetPos(newPos - targetPly:GetViewOffset())
                                targetPly:SetEyeAngles(newAng)
                                
                                if packet.scale then
                                    local newScale = tonumber(packet.scale[1]) or 1.0
                                    if newScale <= 0.01 then
                                        if targetPly:Alive() then
                                            targetPly:Kill()
                                            print(string.format("[GModLiveLink] Player %s died from being crushed (scale: %.3f)", targetPly:Name(), newScale))
                                        end
                                    else
                                        targetPly:SetModelScale(newScale, 0)
                                    end
                                end
                                
                                targetPly.LastBlenderMoveTime = RealTime()
                                print(string.format("[GModLiveLink] Teleported player %s to Vector(%.2f, %.2f, %.2f)", targetPly:Name(), newPos.x, newPos.y, newPos.z))
                            else
                                if not packet.steamid and not packet.name and IsValid(operator_ent) then
                                    operator_ent:SetPos(newPos)
                                    operator_ent:SetAngles(newAng)
                                    print(string.format("[GModLiveLink] Moved Blender Operator to Vector(%.2f, %.2f, %.2f)", newPos.x, newPos.y, newPos.z))
                                else
                                    local ply = player.GetAll()[1]
                                    if IsValid(ply) then
                                        if ply:GetMoveType() ~= MOVETYPE_NOCLIP then
                                            ply:SetMoveType(MOVETYPE_NOCLIP)
                                            print("[GModLiveLink] Enabling NOCLIP due to Blender control.")
                                        end
                                        ply:SetPos(newPos - ply:GetViewOffset())
                                        ply:SetEyeAngles(newAng)
                                        ply.LastBlenderMoveTime = RealTime()
                                        print(string.format("[GModLiveLink] Teleported player to Vector(%.2f, %.2f, %.2f)", newPos.x, newPos.y, newPos.z))
                                    end
                                end
                            end
                        elseif packet.type == "entity_transform" then
                            local ent = nil
                            if packet.gmod_id then
                                ent = Entity(packet.gmod_id)
                            end
                            
                            -- Fallback to search: try finding entity by its target name
                            if not IsValid(ent) then
                                local entName = packet.name
                                for _, e in ipairs(ents.GetAll()) do
                                    if e:GetName() == entName or (e:GetClass() == "prop_physics" and e:GetModel() and string.find(e:GetModel(), entName)) then
                                        ent = e
                                        break
                                    end
                                end
                            end
                            
                            if IsValid(ent) then
                                local posTable = packet.pos
                                local angTable = packet.ang
                                local newPos = Vector(posTable[1], posTable[2], posTable[3])
                                local newAng = Angle(angTable[1], angTable[2], angTable[3])
                                
                                 -- If it's a ragdoll, we must move all physics objects to prevent constraint explosion
                                 if ent:GetClass() == "prop_ragdoll" then
                                     local oldPos = ent:GetPos()
                                     local oldAng = ent:GetAngles()
                                     
                                     local count = ent:GetPhysicsObjectCount() or 0
                                     local physObjs = {}
                                     for i = 0, count - 1 do
                                         local phys = ent:GetPhysicsObjectNum(i)
                                         if IsValid(phys) then
                                             local pPos = phys:GetPos()
                                             local pAng = phys:GetAngles()
                                             local lPos, lAng = WorldToLocal(pPos, pAng, oldPos, oldAng)
                                             table.insert(physObjs, { phys = phys, lPos = lPos, lAng = lAng })
                                         end
                                     end
                                     
                                     ent:SetPos(newPos)
                                     ent:SetAngles(newAng)
                                     
                                     for _, data in ipairs(physObjs) do
                                         local wPos, wAng = LocalToWorld(data.lPos, data.lAng, newPos, newAng)
                                         data.phys:SetPos(wPos)
                                         data.phys:SetAngles(wAng)
                                         data.phys:Wake()
                                     end
                                 else
                                     ent:SetPos(newPos)
                                     ent:SetAngles(newAng)
                                 end
                                 
                                 if packet.scale then
                                     local newScale = tonumber(packet.scale[1]) or 1.0
                                     newScale = math.Clamp(newScale, 0.01, 100.0) -- Prevents singular matrix with 0 scale
                                     ent:SetModelScale(newScale, 0)
                                 end
                                 
                                 ent.LastBlenderMoveTime = RealTime()
                                 print(string.format("[GModLiveLink] Moved prop %d (%s) to Vector(%.2f, %.2f, %.2f) with scale %.2f", ent:EntIndex(), ent:GetClass(), newPos.x, newPos.y, newPos.z, ent:GetModelScale()))
                                 
                                 -- Freeze physics if moved by Blender to prevent gravity fight
                                 SetEntityPhysicsFrozen(ent, true)
                            end
                        elseif packet.type == "freeze_prop" then
                            local ent = Entity(packet.gmod_id)
                            if IsValid(ent) then
                                SetEntityPhysicsFrozen(ent, packet.frozen)
                                ent.BlenderPhysicsFrozen = packet.frozen
                                print(string.format("[GModLiveLink] Set prop %d frozen state to %s", packet.gmod_id, tostring(packet.frozen)))
                            end
                        elseif packet.type == "delete_entity" then
                            local ent = Entity(packet.gmod_id)
                            if IsValid(ent) then
                                print(string.format("[GModLiveLink] Deleting prop %d (%s) due to Blender request.", packet.gmod_id, ent:GetClass()))
                                ent:Remove()
                            end
                        end
                    end
                end
            end
        end,
        failed = function(err)
            is_polling = false
            consecutive_failures = consecutive_failures + 1
            if consecutive_failures >= 15 and gmod_livelink_running then
                gmod_livelink_running = false
                hook.Remove("Think", "GMod_LiveLink_Server_Sync")
                print("[GModLiveLink] Blender server connection lost (15 consecutive failures). Live Link paused to prevent server lag.")
            end
        end
    })
end

local function LiveLinkServerTick()
    if not gmod_livelink_running then return end

    local sync_interval = GetConVar("gmod_livelink_interval"):GetFloat() or 0.05
    local time = RealTime()
    if time >= next_sync_time then
        next_sync_time = time + sync_interval
        SendServerPlayerUpdate()
        PollBlenderServerUpdates()
    end

    -- Automatically restore physics motion on props after Blender drag ends
    local dragEnts = {}
    for _, ent in ipairs(ents.FindByClass("prop_physics")) do table.insert(dragEnts, ent) end
    for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do table.insert(dragEnts, ent) end
    
    for _, ent in ipairs(dragEnts) do
        if ent.LastBlenderMoveTime and (time - ent.LastBlenderMoveTime) > 0.5 then
            if not ent.BlenderPhysicsFrozen then
                SetEntityPhysicsFrozen(ent, false)
                print("[GModLiveLink] Restored physics motion for entity " .. ent:EntIndex() .. " (Blender drag stopped).")
            end
            ent.LastBlenderMoveTime = nil
        end
    end

    -- Automatically restore normal walk movement on players after Blender drag ends
    for _, ply in ipairs(player.GetAll()) do
        if ply.LastBlenderMoveTime and (time - ply.LastBlenderMoveTime) > 0.5 then
            if ply:GetMoveType() == MOVETYPE_NOCLIP then
                ply:SetMoveType(MOVETYPE_WALK)
                print("[GModLiveLink] Restored normal WALK physics for player " .. ply:Name() .. " (Blender drag stopped).")
            end
            ply.LastBlenderMoveTime = nil
        end
    end
end

concommand.Add("gmod_livelink_server_start", function(ply, cmd, args)
    -- Allow execution from server console or admin
    if IsValid(ply) and not ply:IsAdmin() then return end

    if gmod_livelink_running then
        print("[GModLiveLink] Server Live Link is already running.")
        return
    end

    last_sent_entities = {}
    is_sending_update = false
    is_polling = false

    gmod_livelink_running = true
    hook.Add("Think", "GMod_LiveLink_Server_Sync", LiveLinkServerTick)
    print("[GModLiveLink] Server-side Live Link started!")
end)

concommand.Add("gmod_livelink_server_stop", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then return end

    if not gmod_livelink_running then
        print("[GModLiveLink] Server Live Link is not running.")
        return
    end

    gmod_livelink_running = false
    hook.Remove("Think", "GMod_LiveLink_Server_Sync")
    last_sent_entities = {}
    is_sending_update = false
    is_polling = false
    print("[GModLiveLink] Server-side Live Link stopped.")
end)

-- Start the hook only when gmod_livelink_server_start is run
-- hook.Add("Think", "GMod_LiveLink_Server_Sync", LiveLinkServerTick)

concommand.Add("gmod_livelink_teleport", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply:IsAdmin() and not game.SinglePlayer() then return end

    local x = tonumber(args[1])
    local y = tonumber(args[2])
    local z = tonumber(args[3])
    local p = tonumber(args[4])
    local yaw = tonumber(args[5])
    local r = tonumber(args[6])

    if x and y and z then
        ply:SetPos(Vector(x, y, z))
    end
    if p and yaw and r then
        ply:SetEyeAngles(Angle(p, yaw, r))
    end
end)

concommand.Add("gmod_livelink_status", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then return end
    print("=== GMod Live Link Status ===")
    print("Running: " .. tostring(gmod_livelink_running))
    print("Host: " .. GetConVar("gmod_livelink_host"):GetString())
    print("Port: " .. GetConVar("gmod_livelink_port"):GetInt())
    print("Interval: " .. GetConVar("gmod_livelink_interval"):GetFloat() .. "s")
    print("Consecutive Failures: " .. consecutive_failures)
    print("Active Synced Props: " .. table.Count(last_sent_entities))
    print("=============================")
end)

-- Real-time prop spawn/delete sync
local function SendEntitySpawn(ent)
    if not gmod_livelink_running then return end
    if not IsValid(ent) then return end
    
    if not IsSyncableEntity(ent) then
        return
    end

    local host = GetConVar("gmod_livelink_host"):GetString()
    local port = GetConVar("gmod_livelink_port"):GetInt()

    local pos = ent:GetPos()
    local ang = ent:GetAngles()

    local bgs = {}
    for bg_id = 0, ent:GetNumBodyGroups() - 1 do
        bgs[tostring(bg_id)] = ent:GetBodygroup(bg_id)
    end

    HTTP({
        url = "http://" .. host .. ":" .. port .. "/update",
        method = "POST",
        headers = { ["Content-Type"] = "application/json" },
        body = util.TableToJSON({
            type = "entity_spawn",
            gmod_id = ent:EntIndex(),
            model = ent:GetModel(),
            pos = { pos.x, pos.y, pos.z },
            ang = { ang.p, ang.y, ang.r },
            skin = ent:GetSkin(),
            bodygroups = bgs,
            obb_mins = { ent:OBBMins().x, ent:OBBMins().y, ent:OBBMins().z },
            obb_maxs = { ent:OBBMaxs().x, ent:OBBMaxs().y, ent:OBBMaxs().z }
        }),
        success = function(code, body)
            -- success
        end
    })
end

local function SendEntityDelete(ent)
    if not gmod_livelink_running then return end
    if not IsValid(ent) then return end
    
    if not IsSyncableEntity(ent) then
        return
    end

    local host = GetConVar("gmod_livelink_host"):GetString()
    local port = GetConVar("gmod_livelink_port"):GetInt()

    HTTP({
        url = "http://" .. host .. ":" .. port .. "/update",
        method = "POST",
        headers = { ["Content-Type"] = "application/json" },
        body = util.TableToJSON({
            type = "entity_delete",
            gmod_id = ent:EntIndex()
        }),
        success = function(code, body)
            -- success
        end
    })
end

hook.Add("OnEntityCreated", "GMod_LiveLink_Spawn", function(ent)
    timer.Simple(0.1, function()
        SendEntitySpawn(ent)
    end)
end)

hook.Add("EntityRemoved", "GMod_LiveLink_Delete", function(ent)
    if IsValid(ent) then
        last_sent_entities[ent:EntIndex()] = nil
        last_bone_states[tostring(ent:EntIndex())] = nil -- Clear bone states cache
    end
    SendEntityDelete(ent)
end)
