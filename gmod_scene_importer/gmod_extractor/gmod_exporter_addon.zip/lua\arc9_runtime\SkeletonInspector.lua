-- SkeletonInspector.lua
-- Captures skeletal bone positions and angles relative to the weapon root, ignoring uninitialized bones.

return function(db, wep, vm)
    db.skeletons = {}

    -- Determine reference entity (WeaponRoot)
    local ref_ent = vm
    if not IsValid(ref_ent) then
        ref_ent = wep
    end

    local ref_pos = ref_ent:GetPos()
    local ref_ang = ref_ent:GetAngles()

    for guid_str, ent in pairs(db.guid_to_entity) do
        ent:SetupBones()
        local bone_count = ent:GetBoneCount() or 0
        if bone_count > 0 then
            local skeleton = {
                entity_id = guid_str,
                bone_count = bone_count,
                bones = {}
            }

            for i = 0, bone_count - 1 do
                local b_name = ent:GetBoneName(i)
                local parent_idx = ent:GetBoneParent(i)
                local cur_mat = ent:GetBoneMatrix(i)

                local bone_data = {
                    id = i,
                    name = b_name,
                    parent = parent_idx,
                    pos = nil,
                    ang = nil
                }

                local cur_mat
                if ent:GetClass() == "gmod_hands" and IsValid(vm) then
                    local vm_bone_idx = vm:LookupBone(b_name)
                    if vm_bone_idx and vm_bone_idx >= 0 then
                        cur_mat = vm:GetBoneMatrix(vm_bone_idx)
                    end
                end
                if not cur_mat then
                    cur_mat = ent:GetBoneMatrix(i)
                end

                local b_pos, b_ang
                if cur_mat then
                    b_pos = cur_mat:GetTranslation()
                    b_ang = cur_mat:GetAngles()
                else
                    if ent:GetClass() == "gmod_hands" and IsValid(vm) then
                        local vm_bone_idx = vm:LookupBone(b_name)
                        if vm_bone_idx and vm_bone_idx >= 0 then
                            b_pos, b_ang = vm:GetBonePosition(vm_bone_idx)
                        end
                    end
                    if not b_pos then
                        b_pos, b_ang = ent:GetBonePosition(i)
                    end
                end

                if b_pos and b_ang then
                    local is_invalid = false
                    if b_pos:LengthSqr() < 0.001 then
                        is_invalid = true
                    end

                    if not is_invalid then
                        -- Convert world position and angles of bone to local space of the WeaponRoot
                        local local_pos, local_ang = WorldToLocal(b_pos, b_ang, ref_pos, ref_ang)
                        bone_data.pos = {local_pos.x, local_pos.y, local_pos.z}
                        bone_data.ang = {local_ang.p, local_ang.y, local_ang.r}
                    end
                end

                table.insert(skeleton.bones, bone_data)
            end

            db.skeletons[guid_str] = skeleton
        end
    end
end
