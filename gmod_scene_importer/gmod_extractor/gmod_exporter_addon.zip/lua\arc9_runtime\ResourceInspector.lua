-- ResourceInspector.lua
-- Extracts unique model resources, skins, bodygroups, and submaterials.

return function(db, wep, vm)
    db.resources = {}

    for guid_str, ent in pairs(db.guid_to_entity) do
        local mdl = ent:GetModel()
        if mdl and mdl ~= "" then
            local bodygroups = {}
            local num_bg = ent:GetNumBodyGroups() or 0
            for bg = 0, num_bg - 1 do
                local bg_name = ent:GetBodygroupName(bg) or ("bg_" .. bg)
                table.insert(bodygroups, {
                    id = bg,
                    name = bg_name,
                    value = ent:GetBodygroup(bg) or 0
                })
            end

            local submaterials = {}
            for i = 0, 31 do
                local sub = ent:GetSubMaterial(i)
                if sub and sub ~= "" then
                    submaterials[tostring(i)] = sub
                end
            end

            db.resources["res_" .. guid_str] = {
                id = "res_" .. guid_str,
                mdl = mdl,
                skin = ent:GetSkin() or 0,
                bodygroups = bodygroups,
                submaterials = submaterials,
                materials = {
                    overrides = {},
                    submaterials = submaterials
                }
            }
        end
    end
end
