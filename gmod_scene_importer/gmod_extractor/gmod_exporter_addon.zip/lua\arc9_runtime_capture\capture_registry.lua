ARC9_CAPTURE = ARC9_CAPTURE or {}
ARC9_CAPTURE.Registry = ARC9_CAPTURE.Registry or {}

-- We track all newly created clientside models. 
hook.Add("OnEntityCreated", "ARC9_RuntimeCapture_Registry", function(ent)
    if not IsValid(ent) then return end
    -- Wait 1 frame so entity class is fully assigned
    timer.Simple(0, function()
        if not IsValid(ent) then return end
        local class = ent:GetClass()
        if class == "class C_BaseAnimating" or class == "class C_HL2MPRagdoll" or class == "viewmodel" or class == "gmod_hands" then
            ARC9_CAPTURE.Registry[ent] = true
        end
    end)
end)

-- Clean up registry periodically to avoid memory leaks with dead entities
timer.Create("ARC9_Capture_Registry_Cleanup", 5, 0, function()
    for ent, _ in pairs(ARC9_CAPTURE.Registry) do
        if not IsValid(ent) then
            ARC9_CAPTURE.Registry[ent] = nil
        end
    end
end)
