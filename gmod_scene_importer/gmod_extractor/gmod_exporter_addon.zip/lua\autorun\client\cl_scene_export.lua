--[[
    Client-side bridge for SceneExport server commands.
]]

if SERVER then return end

timer.Simple(1, function()
    concommand.Add("advdupe2_export_to_json", function(ply, cmd, args)
        if not args[1] or args[1] == "" then
            print("[SceneExport] Usage: advdupe2_export_to_json <filename> [outname]")
            return
        end
        net.Start("SceneExport_Dupe")
        net.WriteString(args[1])
        net.SendToServer()
        print("[SceneExport] Sent dupe file export request to server...")
    end)

    concommand.Add("advdupe2_export_clipboard", function(ply, cmd, args)
        local outName = args[1] or "gmod_scene_dupe.json"
        net.Start("SceneExport_Clipboard")
        net.WriteString(outName)
        net.SendToServer()
        print("[SceneExport] Exporting AdvDupe2 clipboard to JSON...")
    end)

    print("[SceneExport] Client bridges:")
    print("  advdupe2_export_clipboard [file]  -- export current AdvDupe2 copy buffer")
    print("  advdupe2_export_to_json <file>    -- export saved dupe file")
end)
