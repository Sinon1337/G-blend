-- EntityRuntimeInspector.lua
-- Discovers and registers all relevant viewmodel/attachment entities under unique Runtime IDs.

local function ScanChildren(parent_ent, collected)
    if not IsValid(parent_ent) then return end
    local children = parent_ent:GetChildren() or {}
    for _, child in ipairs(children) do
        if IsValid(child) and not collected[child] then
            local mdl = child:GetModel()
            if mdl and mdl ~= "" and mdl ~= "models/error.mdl" then
                collected[child] = true
                ScanChildren(child, collected)
            end
        end
    end
end

return function(db, wep, vm)
    local collected = {}

    -- 1. Scan ViewModel and hands (exclude SWEP itself and its children to avoid third-person worldmodel duplicate)
    if IsValid(vm) then collected[vm] = true end

    local ply = LocalPlayer()
    if IsValid(ply) then
        local hands = ply:GetHands()
        if IsValid(hands) then collected[hands] = true end
    end

    -- 2. Scan ARC9 VModel elements (ignore wep.CSModel which is the third-person WorldModel, and filter out RT scope/world duplicates via custom .NoDraw flag)
    if IsValid(wep) and wep.VModel then
        for _, model in pairs(wep.VModel) do
            if IsValid(model) and not model.NoDraw then collected[model] = true end
        end
    end

    -- 3. Scan first-person viewmodel attachments only (ignore slot.CSModel and sub.CSModel, and filter via custom .NoDraw flag)
    if IsValid(wep) and wep.Attachments then
        for _, slot in pairs(wep.Attachments) do
            if IsValid(slot.Ent) and not slot.Ent.NoDraw then collected[slot.Ent] = true end
            if slot.SubAttachments then
                for _, sub in pairs(slot.SubAttachments) do
                    if IsValid(sub.Ent) and not sub.Ent.NoDraw then collected[sub.Ent] = true end
                end
            end
        end
    end

    -- 4. Scan children of all gathered entities recursively
    local initial_ents = {}
    for ent, _ in pairs(collected) do
        table.insert(initial_ents, ent)
    end
    for _, ent in ipairs(initial_ents) do
        ScanChildren(ent, collected)
    end

    -- 5. Establish stable unique GUID mapping
    db.entity_to_guid = {}
    db.guid_to_entity = {}
    local guid = 1

    local sorted_ents = {}
    for ent, _ in pairs(collected) do
        table.insert(sorted_ents, ent)
    end
    table.sort(sorted_ents, function(a, b)
        return tostring(a) < tostring(b)
    end)

    for _, ent in ipairs(sorted_ents) do
        local guid_str = tostring(guid)
        db.entity_to_guid[ent] = guid_str
        db.guid_to_entity[guid_str] = ent
        guid = guid + 1
    end

    -- 6. Populate entities record
    for guid_str, ent in pairs(db.guid_to_entity) do
        db.entities[guid_str] = {
            id = guid_str,
            class = ent:GetClass(),
            model = ent:GetModel(),
            skin = ent:GetSkin() or 0
        }
    end

    -- 7. Diagnostic Dump
    local log = {}
    table.insert(log, "=== ARC9 ENTITY DUMP ===")
    table.insert(log, "ViewModel (vm): " .. tostring(vm) .. " | Model: " .. tostring(IsValid(vm) and vm:GetModel() or "N/A"))
    table.insert(log, "SWEP (wep): " .. tostring(wep) .. " | Model: " .. tostring(IsValid(wep) and wep:GetModel() or "N/A"))
    table.insert(log, "wep.CSModel: " .. tostring(wep.CSModel) .. " | Model: " .. tostring(IsValid(wep.CSModel) and wep.CSModel:GetModel() or "N/A"))
    
    if IsValid(wep) then
        if wep.VModel then
            table.insert(log, "\n--- wep.VModel ---")
            for k, model in pairs(wep.VModel) do
                if IsValid(model) then
                    local nodraw = model:GetNoDraw()
                    local scale = model:GetModelScale()
                    table.insert(log, string.format("  [%s] = %s | Model: %s | GetNoDraw(): %s | ModelScale: %s", tostring(k), tostring(model), tostring(model:GetModel()), tostring(nodraw), tostring(scale)))
                    
                    -- Dump all Lua fields of this entity
                    local fields = {}
                    local ent_tbl = model.GetTable and model:GetTable()
                    if ent_tbl then
                        for fkey, fval in pairs(ent_tbl) do
                            if type(fval) ~= "function" then
                                table.insert(fields, string.format("%s = %s", tostring(fkey), tostring(fval)))
                            end
                        end
                    end
                    table.insert(log, "    Lua fields: " .. table.concat(fields, ", "))
                end
            end
        end
    end

    table.insert(log, "\n--- Collected Entities Mapping ---")
    for _, ent in ipairs(sorted_ents) do
        local guid_str = db.entity_to_guid[ent]
        table.insert(log, string.format("  GUID [%s] = %s | Model: %s | Class: %s | Parent: %s | MoveParent: %s", guid_str, tostring(ent), tostring(ent:GetModel()), tostring(ent:GetClass()), tostring(ent:GetParent()), tostring(ent:GetMoveParent())))
    end

    file.CreateDir("gmod_scene_export")
    file.Write("gmod_scene_export/ents_dump.txt", table.concat(log, "\n"))
end
