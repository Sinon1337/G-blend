ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.GetSkeleton(ent)
    local bones = {}
    for i = 0, ent:GetBoneCount() - 1 do
        local name = ent:GetBoneName(i)
        local parent_id = ent:GetBoneParent(i)
        local parent_name = (parent_id and parent_id >= 0) and ent:GetBoneName(parent_id) or nil
        local bone_mat = ent:GetBoneMatrix(i)
        local mat_arr = nil
        
        if bone_mat then
            mat_arr = {}
            for r = 1, 4 do
                for c = 1, 4 do
                    table.insert(mat_arr, bone_mat:GetField(r, c))
                end
            end
        end
        
        table.insert(bones, {
            name = name,
            parent = parent_name,
            current_matrix = mat_arr
        })
    end
    return bones
end
