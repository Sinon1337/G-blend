--[[
    Shared helpers for GMod Scene Export -> Blender JSON
]]

SceneExport = SceneExport or {}

SceneExport.SKIP_CLASSES = {
    worldspawn = true,
    player = true,
    prop_effect = true,    -- Effect Resizer gizmo circle - skip itself, but export its children
    gmod_hands = true,
    predicted_viewmodel = true,
    func_detail = true,
    func_brush = true,
    func_wall = true,
    func_breakable = true,
    func_physbox = true,
    func_lod = true,
}

-- Returns the prop_effect parent if this entity is a direct child of one (Effect Resizer)
function SceneExport.GetPropEffectParent(ent)
    if not IsValid(ent) then return nil end
    local parent = ent:GetParent()
    if IsValid(parent) and parent:GetClass() == "prop_effect" then
        return parent
    end
    return nil
end

function SceneExport.ShouldExportEntity(ent, opts)
    opts = opts or {}

    if not IsValid(ent) then return false end
    if ent.IsWeaponStatue then return true end

    local cls = ent:GetClass()

    local cur = ent
    while IsValid(cur) do
        if cur.IsPlayer and cur:IsPlayer() then return false end
        cur = cur:GetParent()
    end
    if ent.IsWeapon and ent:IsWeapon() then return false end
    if string.find(cls, "viewmodel", 1, true) then return false end
    if SceneExport.SKIP_CLASSES[cls] then return false end

    local model = ent:GetModel()
    if not model or model == "" or model == "models/error.mdl" then return false end

    -- We allow player models since the class 'player' and IsPlayer() checks above already filter out actual player characters.


    local allowed =
        string.StartWith(cls, "prop_") or
        string.StartWith(cls, "npc_") or
        string.StartWith(cls, "sw_") or
        string.StartWith(cls, "lvs_") or
        cls == "ent_bonemerged" or
        cls == "gmod_cameraprop" or
        cls == "hl_camera" or
        cls == "gmod_rtcamera" or
        cls == "gmod_lamp" or
        cls == "gmod_light" or
        cls == "gmod_softlamp"

    if not allowed then return false end

    if not opts.include_map then
        local mapID = ent.MapCreationID and ent:MapCreationID()
        if mapID and mapID ~= -1 then return false end
    end

    if opts.only_mine and CLIENT then
        local ply = LocalPlayer()
        if IsValid(ply) and ent.CPPIGetOwner then
            local owner = ent:CPPIGetOwner()
            if IsValid(owner) and owner ~= ply then return false end
        end
    end

    return true
end

function SceneExport.WriteJSON(exportData, outName)
    outName = outName or "gmod_scene_export.json"
    if not string.EndsWith(string.lower(outName), ".json") then
        outName = outName .. ".json"
    end

    file.CreateDir("gmod_scene_export")
    local path = "gmod_scene_export/" .. outName
    local jsonStr = util.TableToJSON(exportData, true)
    if not jsonStr then
        print("[SceneExport] JSON encoding failed!")
        return false
    end

    file.Write(path, jsonStr)
    print("[SceneExport] ========================================")
    local count = #(exportData.objects or {})
    if count == 0 and exportData.attachments then
        count = #exportData.attachments
    end
    if count == 0 and exportData.scene and exportData.scene.nodes then
        count = #exportData.scene.nodes
    end
    print("[SceneExport] Exported " .. count .. " items")
    print("[SceneExport] Saved to: garrysmod/data/" .. path)
    print("[SceneExport] ========================================")
    return true
end

function SceneExport.ComputeCentroidFromObjects(objects)
    if not objects or #objects == 0 then
        return Vector(0, 0, 0)
    end

    local sum = Vector(0, 0, 0)
    for _, obj in ipairs(objects) do
        local p = obj.position
        if p then
            sum = sum + Vector(p[1] or p.x or 0, p[2] or p.y or 0, p[3] or p.z or 0)
        end
    end
    return sum / #objects
end

function SceneExport.ApplyCentroid(objects, centroid)
    for _, obj in ipairs(objects) do
        if obj.position then
            obj.position = {
                obj.position[1] - centroid.x,
                obj.position[2] - centroid.y,
                obj.position[3] - centroid.z,
            }
        end

        if obj.bones then
            for _, bone in ipairs(obj.bones) do
                if bone.pos then
                    bone.pos = {
                        bone.pos[1] - centroid.x,
                        bone.pos[2] - centroid.y,
                        bone.pos[3] - centroid.z,
                    }
                end
            end
        end
    end

    return objects
end
