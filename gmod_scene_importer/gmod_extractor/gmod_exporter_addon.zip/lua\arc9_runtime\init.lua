-- init.lua
-- Orchestrates sequential inspectors to build the RuntimeDatabase and calls the exporter.

local WeaponRuntimeInspector = include("arc9_runtime/WeaponRuntimeInspector.lua")
local EntityRuntimeInspector = include("arc9_runtime/EntityRuntimeInspector.lua")
local SkeletonInspector = include("arc9_runtime/SkeletonInspector.lua")
local AttachmentInspector = include("arc9_runtime/AttachmentInspector.lua")
local RelationshipInspector = include("arc9_runtime/RelationshipInspector.lua")
local ResourceInspector = include("arc9_runtime/ResourceInspector.lua")
local MaterialInspector = include("arc9_runtime/MaterialInspector.lua")
local AnimationInspector = include("arc9_runtime/AnimationInspector.lua")
local TransformInspector = include("arc9_runtime/TransformInspector.lua")
local RuntimeInspector = include("arc9_runtime/RuntimeInspector.lua")
local DebugInspector = include("arc9_runtime/DebugInspector.lua")
local FrameDumper = include("arc9_runtime/FrameDumper.lua")
local Exporter = include("arc9_runtime/Exporter.lua")

return function(wep, vm, outName)
    local db = {
        version = 6,
        CoordinateSystem = {
            units = "inch",
            forward = "X",
            right = "Y",
            up = "Z",
            handedness = "left",
            scale = 0.0254
        },
        metadata = {},
        entities = {},
        resources = {},
        scene = {
            nodes = {}
        },
        skeletons = {},
        attachments = {},
        materials = {},
        animations = {},
        runtime = {},
        debug = {},
        framedump = {},  -- Runtime Frame Dumper output
    }

    -- Run sequential modular collectors
    WeaponRuntimeInspector(db, wep, vm)
    EntityRuntimeInspector(db, wep, vm)
    SkeletonInspector(db, wep, vm)
    AttachmentInspector(db, wep, vm)
    RelationshipInspector(db, wep, vm)
    ResourceInspector(db, wep, vm)
    MaterialInspector(db, wep, vm)
    AnimationInspector(db, wep, vm)
    TransformInspector(db, wep, vm)
    RuntimeInspector(db, wep, vm)
    DebugInspector(db, wep, vm)
    FrameDumper(db, wep, vm)  -- Snapshot all child entities' world transforms

    -- Export finalized RuntimeDatabase
    return Exporter(db, outName)
end
