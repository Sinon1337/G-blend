ARC9_CAPTURE = ARC9_CAPTURE or {}

function ARC9_CAPTURE.GetRenderMatrix(ent)
    local mat = ent:GetRenderMatrix()
    if not mat then
        mat = Matrix()
        mat:SetTranslation(ent:GetPos())
        mat:SetAngles(ent:GetAngles())
    end
    
    local out = {}
    for r = 1, 4 do
        for c = 1, 4 do
            table.insert(out, mat:GetField(r, c))
        end
    end
    return out
end
