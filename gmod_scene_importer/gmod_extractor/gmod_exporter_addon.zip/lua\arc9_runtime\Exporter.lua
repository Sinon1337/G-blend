-- Exporter.lua
-- Serializes the populated RuntimeDatabase to a JSON file named arc9_runtime_scene.json.

return function(db, outName)
    outName = outName or "arc9_runtime_scene.json"
    if not string.EndsWith(string.lower(outName), ".json") then
        outName = outName .. ".json"
    end

    -- Clean up temporary GMod userdata references from db table before serializing
    db.entity_to_guid = nil
    db.guid_to_entity = nil

    file.CreateDir("gmod_scene_export")
    local path = "gmod_scene_export/" .. outName

    local jsonStr = util.TableToJSON(db, true)
    if not jsonStr then
        print("[SceneExport] Exporter failed: JSON encoding error.")
        return false
    end

    file.Write(path, jsonStr)
    print("[SceneExport] ========================================")
    print("[SceneExport] ARC9 Runtime Scene Snapshot successfully exported!")
    print("[SceneExport] Saved to: garrysmod/data/" .. path)
    print("[SceneExport] ========================================")
    return true
end
