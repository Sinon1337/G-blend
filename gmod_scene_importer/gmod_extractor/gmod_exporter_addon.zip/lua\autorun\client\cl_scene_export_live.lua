--[[
    Client-side scene export for Blender import.

    Commands:
      gmod_scene_export_area [half_size] [filename]
          Export props inside a box around your crosshair (AdvDupe2-style area).
          Default half_size: 500 (1000 unit cube). Uses advdupe2_area_copy_size if set.

      gmod_scene_export_look [filename]
          Export the entity you are looking at (+ parents/children tree).

      gmod_scene_export_live [filename]
          Export all player-spawned props in the whole map (strict filter, no map/player junk).
]]

if SERVER then return end

local function GetUniversalScale(ent)
    if not IsValid(ent) then return {1, 1, 1} end

    -- 1. If we can get a non-uniform/scaled bone matrix, it's the absolute final world scale
    if ent.GetBoneMatrix then
        local bmat = ent:GetBoneMatrix(0)
        if bmat then
            local s = bmat:GetScale()
            if s and (math.abs(s.x - 1) > 0.001 or math.abs(s.y - 1) > 0.001 or math.abs(s.z - 1) > 0.001) then
                return {s.x, s.y, s.z}
            end
        end
    end

    -- 2. Fallback to local scale accumulators
    local scaleVec = Vector(1, 1, 1)

    -- Check if this is a child of a prop_effect (for effect resizers)
    local parent = ent:GetParent()
    if IsValid(parent) and parent:GetClass() == "prop_effect" then
        if parent.scalevec then
            scaleVec = parent.scalevec
        elseif parent.effectresizedata and parent.effectresizedata[2] then
            scaleVec = parent.effectresizedata[2]
        else
            local nwv = parent:GetNWVector("Scale")
            if nwv and nwv:LengthSqr() > 0.001 then
                scaleVec = nwv
            else
                local nwv2 = parent:GetNWVector("PropScale")
                if nwv2 and nwv2:LengthSqr() > 0.001 then
                    scaleVec = nwv2
                end
            end
        end

        -- Check parent's RenderMultiply matrix
        if parent.GetMatrix then
            local mat = parent:GetMatrix("RenderMultiply")
            if mat then
                local s = mat:GetScale()
                if s and s.x > 0.001 and s.y > 0.001 and s.z > 0.001 then
                    scaleVec = s
                end
            end
        end
    end

    -- Direct custom scale variables on the entity
    if ent.scalevec and type(ent.scalevec) == "Vector" then
        scaleVec = ent.scalevec
    elseif ent.effectresizedata and ent.effectresizedata[2] and type(ent.effectresizedata[2]) == "Vector" then
        scaleVec = ent.effectresizedata[2]
    end

    -- RenderMultiply Matrix on the entity itself (Effect Resizer client side)
    if ent.GetMatrix then
        local mat = ent:GetMatrix("RenderMultiply")
        if mat then
            local s = mat:GetScale()
            if s and s.x > 0.001 and s.y > 0.001 and s.z > 0.001 then
                scaleVec = s
            end
        end
    end

    -- RenderMultiply NWVector
    local rmnwv = ent:GetNWVector("RenderMultiplyMatrixScale")
    if rmnwv and rmnwv:LengthSqr() > 0.001 then
        scaleVec = rmnwv
    end

    -- 1. ManipulateBoneScale
    if ent.GetManipulateBoneScale then
        local bs = ent:GetManipulateBoneScale(0)
        if bs and (math.abs(bs.x - 1) > 0.001 or math.abs(bs.y - 1) > 0.001 or math.abs(bs.z - 1) > 0.001) then
            scaleVec = Vector(bs.x, bs.y, bs.z)
        end
    end

    -- 2. Networked Vector
    local nwv = ent:GetNWVector("Scale")
    if nwv and nwv:LengthSqr() > 0.001 then
        scaleVec = nwv
    else
        local nwv2 = ent:GetNWVector("PropScale")
        if nwv2 and nwv2:LengthSqr() > 0.001 then
            scaleVec = nwv2
        end
    end

    -- 3. Custom Lua object variables
    if ent.ModelScale and type(ent.ModelScale) == "Vector" then
        scaleVec = ent.ModelScale
    elseif ent.Scale and type(ent.Scale) == "Vector" then
        scaleVec = ent.Scale
    elseif ent.TargetScale and type(ent.TargetScale) == "Vector" then
        scaleVec = ent.TargetScale
    end

    -- Multiply by the global model scale
    local ms = ent:GetModelScale() or 1
    return {scaleVec.x * ms, scaleVec.y * ms, scaleVec.z * ms}
end

local function CollectTree(root, opts, out, seen)
    if not IsValid(root) or seen[root] then return end
    if not SceneExport.ShouldExportEntity(root, opts) then return end

    seen[root] = true
    table.insert(out, root)

    local parent = root:GetParent()
    if IsValid(parent) then
        CollectTree(parent, opts, out, seen)
    end

    for _, child in ipairs(root:GetChildren()) do
        CollectTree(child, opts, out, seen)
    end
end

local function CollectInArea(halfSize, opts)
    local ply = LocalPlayer()
    if not IsValid(ply) then return {}, Vector(0, 0, 0), halfSize end

    local tr = ply:GetEyeTrace()
    local center = tr.HitPos
    local B = center - Vector(halfSize, halfSize, halfSize)
    local T = center + Vector(halfSize, halfSize, halfSize)

    local out = {}
    local seen = {}

    for _, ent in ipairs(ents.FindInBox(B, T)) do
        -- Normal entities
        if SceneExport.ShouldExportEntity(ent, opts) and not seen[ent] then
            CollectTree(ent, opts, out, seen)
        end
        -- Children of prop_effect (Effect Resizer)
        if ent:GetClass() == "prop_effect" then
            for _, child in ipairs(ent:GetChildren()) do
                if IsValid(child) and not seen[child] and child:GetModel() and child:GetModel() ~= "" then
                    CollectTree(child, opts, out, seen)
                end
            end
        end
    end

    return out, center, halfSize
end

local function CollectLook(opts)
    local ply = LocalPlayer()
    if not IsValid(ply) then return {} end

    local tr = ply:GetEyeTrace()
    if not tr.Hit or not IsValid(tr.Entity) then
        print("[SceneExport] Look at a prop to export it.")
        return {}
    end

    local out = {}
    local seen = {}
    CollectTree(tr.Entity, opts, out, seen)
    return out
end

local function CollectLive(opts)
    local out = {}
    local seen = {}

    -- Debug dump
    local debug_lines = {}
    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) then
            local parent = ent:GetParent()
            local parent_str = IsValid(parent) and (parent:GetClass() .. " [" .. parent:EntIndex() .. "]") or "none"
            
            local mat_scale = "none"
            if ent.GetMatrix then
                local mat = ent:GetMatrix("RenderMultiply")
                if mat then
                    local s = mat:GetScale()
                    mat_scale = string.format("[%f, %f, %f]", s.x, s.y, s.z)
                end
            end
            
            local bone_scale = "none"
            if ent.GetBoneMatrix then
                local bmat = ent:GetBoneMatrix(0)
                if bmat then
                    local s = bmat:GetScale()
                    bone_scale = string.format("[%f, %f, %f]", s.x, s.y, s.z)
                end
            end
            
            local model_scale = "1"
            if ent.GetModelScale then
                local ms = ent:GetModelScale()
                if ms then model_scale = tostring(ms) end
            end
            
            local manip_scale = "none"
            if ent.GetManipulateBoneScale then
                local ms = ent:GetManipulateBoneScale(0)
                if ms then manip_scale = string.format("[%f, %f, %f]", ms.x, ms.y, ms.z) end
            end
            
            local scale_nwv = "none"
            if ent.GetNWVector then
                local v = ent:GetNWVector("Scale")
                if v then scale_nwv = tostring(v) end
            end
            
            local prop_scale_nwv = "none"
            if ent.GetNWVector then
                local v = ent:GetNWVector("PropScale")
                if v then prop_scale_nwv = tostring(v) end
            end
            
            local rmm_nwv = "none"
            if ent.GetNWVector then
                local v = ent:GetNWVector("RenderMultiplyMatrixScale")
                if v then rmm_nwv = tostring(v) end
            end

            table.insert(debug_lines, string.format("Index: %d | Class: %s | Model: %s | Parent: %s | ShouldExport: %s | MatScale: %s | BoneScale: %s | ModelScale: %s | ManipScale: %s | ScaleNWV: %s | PropScaleNWV: %s | RMMNWV: %s", 
                ent:EntIndex(), ent:GetClass(), ent:GetModel() or "none", parent_str, tostring(SceneExport.ShouldExportEntity(ent, opts)),
                mat_scale, bone_scale, model_scale, manip_scale, scale_nwv, prop_scale_nwv, rmm_nwv))
        end
    end
    file.Write("gmod_scene_export/ents_dump.txt", table.concat(debug_lines, "\n"))

    for _, ent in ipairs(ents.GetAll()) do
        if SceneExport.ShouldExportEntity(ent, opts) and not seen[ent] then
            CollectTree(ent, opts, out, seen)
        end
        -- Collect children of prop_effect (Effect Resizer)
        if ent:GetClass() == "prop_effect" then
            for _, child in ipairs(ent:GetChildren()) do
                if IsValid(child) and not seen[child] and child:GetModel() and child:GetModel() ~= "" then
                    CollectTree(child, opts, out, seen)
                end
            end
        end
    end
    if LocalWeaponStatues then
        for _, ent in ipairs(LocalWeaponStatues) do
            if IsValid(ent) and not seen[ent] then
                CollectTree(ent, opts, out, seen)
            end
        end
    end
    return out
end

local function SerializeEntity(ent, id, entToID)
    local model = ent:GetModel()
    local cls = ent:GetClass()

    -- If this entity is a child of prop_effect (Effect Resizer),
    -- use the prop_effect's world position/angle/scale, not the child's own
    local propEffectParent = SceneExport.GetPropEffectParent(ent)
    local rawPos, rawAng
    if propEffectParent then
        rawPos = propEffectParent:GetPos()
        rawAng = propEffectParent:GetAngles()
    else
        rawPos = ent:GetPos()
        rawAng = ent:GetAngles()
    end

    local scaleVec = GetUniversalScale(ent)

    local bodygroups = {}
    local bodygroup_names = {}
    local numBG = ent:GetNumBodyGroups() or 0
    for bg = 0, numBG - 1 do
        local val = ent:GetBodygroup(bg) or 0
        bodygroups[tostring(bg)] = val
        bodygroup_names[tostring(bg)] = ent:GetBodygroupName(bg) or ("bg_" .. bg)
    end

    local submaterials = {}
    local defaultMats = ent:GetMaterials() or {}
    for mi = 0, #defaultMats - 1 do
        local subMat = ent:GetSubMaterial(mi) or ""
        if subMat ~= "" then submaterials[tostring(mi)] = subMat end
    end

    local parentID = nil
    local isBoneMerge = false
    local parentEnt = ent:GetParent()
    if IsValid(parentEnt) then
        parentID = entToID[parentEnt:EntIndex()]
        if ent.GetEffects then
            isBoneMerge = bit.band(ent:GetEffects(), 4) ~= 0
        end
    end

    local matOverride = ent:GetMaterial() or ""

    local obj = {
        id = id,
        parent_id = parentID,
        is_bonemerge = isBoneMerge,
        is_effect = (propEffectParent ~= nil),
        name = "Entity_" .. id .. "_" .. cls,
        class = cls,
        model = model,
        scale = scaleVec,
        skin = ent:GetSkin() or 0,
        bodygroups = bodygroups,
        bodygroup_names = bodygroup_names,
        intrinsic_materials = defaultMats,
        submaterials = submaterials,
        material = (matOverride ~= "" and matOverride or nil),
        position = {rawPos.x, rawPos.y, rawPos.z},
        rotation_euler = {rawAng.p, rawAng.y, rawAng.r},
        bones = {},
    }

    local numBones = ent:GetBoneCount() or 0
    if numBones > 0 then
        ent:SetupBones()
        for boneID = 0, numBones - 1 do
            local boneName = ent:GetBoneName(boneID)
            if boneName and boneName ~= "" then
                local mat = ent:GetBoneMatrix(boneID)
                if mat then
                    local bPos = mat:GetTranslation()
                    local bAng = mat:GetAngles()
                    table.insert(obj.bones, {
                        id = boneID,
                        name = boneName,
                        pos = {bPos.x, bPos.y, bPos.z},
                        angle = {bAng.p, bAng.y, bAng.r},
                    })
                end
            end
        end
    end

    if cls == "gmod_cameraprop" or cls == "hl_camera" or cls == "gmod_rtcamera" then
        local fov = ent.GetFOV and ent:GetFOV() or 75
        obj.fov = fov
        obj.active = true
    elseif cls == "gmod_lamp" then
        obj.is_lamp = true
        local col = ent:GetColor() or Color(255, 255, 255, 255)
        obj.lamp_color = {col.r, col.g, col.b, col.a}
        obj.lamp_fov = ent.GetLightFOV and ent:GetLightFOV() or 90
        obj.lamp_distance = ent.GetDistance and ent:GetDistance() or 1024
        obj.lamp_brightness = ent.GetBrightness and ent:GetBrightness() or 1
        obj.lamp_texture = ent.GetTexture and ent:GetTexture() or ""
        obj.lamp_on = (ent.GetOn and ent:GetOn() or (ent.GetToggle and ent:GetToggle() or true))
    elseif cls == "gmod_softlamp" then
        obj.is_softlamp = true
        local col = ent.GetLightColor and ent:GetLightColor() or Vector(255, 255, 255)
        obj.lamp_color = {col.x, col.y, col.z, 255}
        obj.lamp_fov = ent.GetLightFOV and ent:GetLightFOV() or 90
        obj.lamp_distance = ent.GetFarZ and ent:GetFarZ() or 1024
        obj.lamp_brightness = ent.GetBrightness and ent:GetBrightness() or 1
        obj.lamp_texture = ent.GetFlashlightTexture and ent:GetFlashlightTexture() or ""
        obj.lamp_on = (ent.GetToggle and ent:GetToggle() or (ent.GetOn and ent:GetOn() or true))
    elseif cls == "gmod_light" then
        obj.is_light = true
        local col = ent:GetColor() or Color(255, 255, 255, 255)
        obj.light_color = {col.r, col.g, col.b, col.a}
        obj.light_brightness = ent.GetBrightness and ent:GetBrightness() or 1
        obj.light_size = ent.GetLightSize and ent:GetLightSize() or 256
        obj.light_on = (ent.GetOn and ent:GetOn() or (ent.GetToggle and ent:GetToggle() or true))
    end

    return obj
end

local function BuildExport(entList, mode, extraMeta)
    local exportData = {
        version = 2.0,
        type = "live_scene",
        export_mode = mode,
        objects = {},
        camera = nil,
        meta = {
            map = game.GetMap(),
            count = #entList,
        },
    }

    if extraMeta then
        for k, v in pairs(extraMeta) do
            exportData.meta[k] = v
        end
    end

    local entToID = {}
    for i, ent in ipairs(entList) do
        entToID[ent:EntIndex()] = i
    end

    for i, ent in ipairs(entList) do
        local obj = SerializeEntity(ent, i, entToID)
        table.insert(exportData.objects, obj)

        if obj.class == "gmod_cameraprop" or obj.class == "hl_camera" or obj.class == "gmod_rtcamera" then
            exportData.camera = {
                fov = obj.fov or 75,
                active = true,
                position = obj.position,
                rotation_euler = obj.rotation_euler,
            }
        end
    end

    if not exportData.camera then
        local ply = LocalPlayer()
        if IsValid(ply) then
            local pos = ply:EyePos()
            local ang = ply:EyeAngles()
            exportData.camera = {
                fov = ply:GetFOV() or 75,
                active = true,
                position = {pos.x, pos.y, pos.z},
                rotation_euler = {ang.p, ang.y, ang.r},
            }
        end
    end

    local centroid = SceneExport.ComputeCentroidFromObjects(exportData.objects)
    SceneExport.ApplyCentroid(exportData.objects, centroid)

    if exportData.camera and exportData.camera.position then
        exportData.camera.position = {
            exportData.camera.position[1] - centroid.x,
            exportData.camera.position[2] - centroid.y,
            exportData.camera.position[3] - centroid.z,
        }
    end

    exportData.meta.centroid = {x = centroid.x, y = centroid.y, z = centroid.z}

    return exportData
end

local function ParseOutName(args, defaultName)
    for _, arg in ipairs(args) do
        if arg ~= "" and not tonumber(arg) then
            return arg
        end
    end
    return defaultName
end

local function RunExport(mode, entList, outName, extraMeta)
    if #entList == 0 then
        print("[SceneExport] Nothing to export for mode: " .. mode)
        return
    end

    local exportData = BuildExport(entList, mode, extraMeta)
    SceneExport.WriteJSON(exportData, outName)
end

local defaultOpts = {
    include_map = false,
    only_mine = false,
    allow_playermodels = true,
}

concommand.Add("gmod_scene_export_area", function(ply, cmd, args)
    local halfSize = tonumber(args[1]) or tonumber(LocalPlayer():GetInfo("advdupe2_area_copy_size")) or 500
    halfSize = math.Clamp(halfSize, 32, 30720)
    local outName = ParseOutName(args, "gmod_scene_area.json")

    print("[SceneExport] Area export: box half-size " .. halfSize .. " around crosshair")

    local entList, center, size = CollectInArea(halfSize, defaultOpts)
    RunExport("area", entList, outName, {
        area_half_size = halfSize,
        area_center = {x = center.x, y = center.y, z = center.z},
    })
end)

concommand.Add("gmod_scene_export_look", function(ply, cmd, args)
    local outName = ParseOutName(args, "gmod_scene_look.json")
    local entList = CollectLook(defaultOpts)
    RunExport("look", entList, outName)
end)

concommand.Add("gmod_scene_export_live", function(ply, cmd, args)
    local outName = ParseOutName(args, "gmod_scene_export.json")
    print("[SceneExport] Live export: all spawned props (strict filter)")
    local entList = CollectLive(defaultOpts)
    RunExport("live", entList, outName)
end)

local function PrintWeaponHierarchy(wep, vm, hands)
    if not IsValid(wep) then return end
    print("\n==========================================================================")
    print("                     ARC9 WEAPON HIERARCHY BLUEPRINT                      ")
    print("==========================================================================")
    
    local vm_model = IsValid(vm) and vm:GetModel() or wep:GetModel()
    print("[VM] Root viewmodel: " .. tostring(vm_model))

    local function FormatLocalCoords(ent)
        if not IsValid(ent) or not IsValid(vm) then return "" end
        local mat = ent:GetWorldTransformMatrix()
        local w_pos, w_ang
        if mat then
            w_pos = mat:GetTranslation()
            w_ang = mat:GetAngles()
        else
            w_pos = ent:GetPos()
            w_ang = ent:GetAngles()
        end
        
        local vm_pos = vm:GetPos()
        local vm_ang = vm:GetAngles()
        local vm_mat = vm:GetWorldTransformMatrix()
        if vm_mat then
            vm_pos = vm_mat:GetTranslation()
            vm_ang = vm_mat:GetAngles()
        end

        local lp, la = WorldToLocal(w_pos, w_ang, vm_pos, vm_ang)
        return string.format("  =>  Pos: (%.2f, %.2f, %.2f)  Ang: (%.1f, %.1f, %.1f)", lp.x, lp.y, lp.z, la.p, la.y, la.r)
    end

    if IsValid(hands) then
        print(" ├── [Hands] Custom Hands: " .. tostring(hands:GetModel()) .. FormatLocalCoords(hands))
    end

    local vmodel_ents = {}
    if wep.VModel then
        for _, ent in pairs(wep.VModel) do
            if IsValid(ent) and not ent.NoDraw then
                table.insert(vmodel_ents, ent)
            end
        end
    end

    local has_slots = wep.Attachments and table.Count(wep.Attachments) > 0
    for idx, ent in ipairs(vmodel_ents) do
        local is_last = (idx == #vmodel_ents) and not has_slots
        local branch = is_last and " └── " or " ├── "
        print(" " .. branch .. "[Part] VModel Part: " .. tostring(ent:GetModel()) .. FormatLocalCoords(ent))
    end

    local function PrintSlotsRecursive(slots, indent)
        if not slots then return end
        local valid_slots = {}
        for _, slot in pairs(slots) do
            if IsValid(slot.Ent) and not slot.Ent.NoDraw then
                table.insert(valid_slots, slot)
            end
        end

        for idx, slot in ipairs(valid_slots) do
            local is_last = (idx == #valid_slots)
            local branch = is_last and " └── " or " ├── "
            local bone_str = slot.Bone and (" (Slot Bone: " .. slot.Bone .. ")") or ""
            print(indent .. branch .. "[Att] Attachment: " .. tostring(slot.Ent:GetModel()) .. bone_str .. FormatLocalCoords(slot.Ent))

            if slot.SubAttachments then
                local next_indent = indent .. (is_last and "     " or " │   ")
                PrintSlotsRecursive(slot.SubAttachments, next_indent)
            end
        end
    end

    if wep.Attachments then
        PrintSlotsRecursive(wep.Attachments, " ")
    end
    print("==========================================================================\n")
end

concommand.Add("gmod_debug_weapon_tree", function(ply, cmd, args)
    local wep = LocalPlayer():GetActiveWeapon()
    if not IsValid(wep) then
        print("[SceneExport] No active weapon found!")
        return
    end
    local vm = LocalPlayer():GetViewModel()
    local hands = LocalPlayer():GetHands()
    if not IsValid(hands) then hands = LocalPlayer():GetViewModel(1) end
    
    PrintWeaponHierarchy(wep, vm, hands)
end)

concommand.Add("gmod_scene_export_arc9", function(ply, cmd, args)
    local outName = args[1] or "arc9_runtime_scene.json"
    
    local wep = LocalPlayer():GetActiveWeapon()
    if not IsValid(wep) then
        print("[SceneExport] Active weapon not found! Equip a weapon first.")
        return
    end
    
    local vm = LocalPlayer():GetViewModel()
    local hands = LocalPlayer():GetHands()
    if not IsValid(hands) then hands = LocalPlayer():GetViewModel(1) end
    
    -- Print hierarchy blueprint
    PrintWeaponHierarchy(wep, vm, hands)
    
    -- We register a hook to grab the real posed matrices during the next render frame
    local hook_name = "GrabViewModelBones_" .. tostring(math.random(1, 100000))
    hook.Add("PostDrawViewModel", hook_name, function(ent_vm, ply, ent_wep)
        hook.Remove("PostDrawViewModel", hook_name)
        
        print("[SceneExport] Running Runtime Scene Snapshot...")
        local snapshot = include("arc9_runtime/init.lua")
        snapshot(wep, vm, outName)
    end)
    
    if IsValid(vm) then vm:SetupBones() end
end)

local drawBonesEnabled = false
concommand.Add("gmod_debug_draw_bones", function()
    drawBonesEnabled = not drawBonesEnabled
    print("[SceneExport] Debug draw bones: " .. tostring(drawBonesEnabled))
    
    if drawBonesEnabled then
        hook.Add("PostDrawViewModel", "DebugDrawViewModelBones", function(vm, ply, wep)
            if not IsValid(vm) or not IsValid(wep) then return end
            
            local debugBones = {}
            local function CollectBones(ent, col, prefix)
                if not IsValid(ent) then return end
                ent:SetupBones()
                for i = 0, ent:GetBoneCount() - 1 do
                    local name = ent:GetBoneName(i)
                    local name_lower = name:lower()
                    
                    -- Filter out duplicate player-rig bones on weapon/attachments/parts
                    local should_skip = false
                    if prefix ~= "Hands" then
                        if string.find(name_lower, "^valvebiped") or string.find(name_lower, "^base human") then
                            should_skip = true
                        end
                    end

                    if not should_skip then
                        local bm = ent:GetBoneMatrix(i)
                        if bm then
                            local bPos = bm:GetTranslation()
                            local parent = ent:GetBoneParent(i)
                            local pPos = nil
                            if parent and parent >= 0 then
                                local pmat = ent:GetBoneMatrix(parent)
                                if pmat then pPos = pmat:GetTranslation() end
                            end
                            table.insert(debugBones, {
                                pos = bPos,
                                ppos = pPos,
                                name = name,
                                color = col,
                                prefix = prefix
                            })
                        end
                    end
                end
            end

            -- 1. Collect ViewModel (Red)
            CollectBones(vm, Color(255, 60, 60), "VM")
            
            -- 2. Collect Hands (Green)
            local hands = ply:GetHands()
            if IsValid(hands) then
                CollectBones(hands, Color(60, 255, 60), "Hands")
            end
            
            -- 3. Collect VModel parts (Blue)
            if wep.VModel then
                for _, ent in pairs(wep.VModel) do
                    if IsValid(ent) and not ent.NoDraw then
                        CollectBones(ent, Color(60, 150, 255), "Part")
                    end
                end
            end
            
            -- 4. Collect Attachment Slots (Yellow)
            local function CollectSlots(slots)
                if not slots then return end
                for _, slot in pairs(slots) do
                    if IsValid(slot.Ent) and not slot.Ent.NoDraw then
                        CollectBones(slot.Ent, Color(255, 200, 0), "Att")
                    end
                    if slot.SubAttachments then
                        CollectSlots(slot.SubAttachments)
                    end
                end
            end
            if wep.Attachments then
                CollectSlots(wep.Attachments)
            end

            -- Draw 3D wireframe points and bone connections
            render.SetColorMaterial()
            for _, b in ipairs(debugBones) do
                render.DrawWireframeSphere(b.pos, 0.08, 4, 4, b.color, true)
                if b.ppos then
                    render.DrawLine(b.pos, b.ppos, b.color, true)
                end
            end

            -- Save to player for HUDPaint rendering
            ply.DebugBonesList = debugBones
        end)

        hook.Add("HUDPaint", "DebugDrawBonesHUD", function()
            if not drawBonesEnabled then return end
            local ply = LocalPlayer()
            local bones = ply.DebugBonesList
            if not bones then return end

            local screenPoints = {}
            local cx, cy = ScrW() / 2, ScrH() / 2
            
            for _, b in ipairs(bones) do
                local sPos = b.pos:ToScreen()
                if sPos.visible then
                    local dx = sPos.x - cx
                    local dy = sPos.y - cy
                    local distToCenter = math.sqrt(dx*dx + dy*dy)
                    
                    table.insert(screenPoints, {
                        x = sPos.x,
                        y = sPos.y,
                        name = "[" .. b.prefix .. "] " .. b.name,
                        color = b.color,
                        dist = distToCenter
                    })
                end
            end

            -- Sort by distance to crosshair
            table.sort(screenPoints, function(a, b) return a.dist < b.dist end)

            surface.SetFont("DermaDefault")
            local drawnLabelsCount = 0
            
            for i, sp in ipairs(screenPoints) do
                -- Display text labels only for the closest 20 bones within 200px of the crosshair
                if drawnLabelsCount < 20 and sp.dist < 200 then
                    drawnLabelsCount = drawnLabelsCount + 1
                    
                    -- Use golden-ratio spiral angles to distribute labels evenly
                    local angle = drawnLabelsCount * 2.3999
                    local dist = 45 + (drawnLabelsCount % 4) * 20

                    local tx = sp.x + math.cos(angle) * dist
                    local ty = sp.y + math.sin(angle) * dist

                    -- Draw line
                    surface.SetDrawColor(0, 0, 0, 180)
                    surface.DrawLine(sp.x, sp.y, tx, ty)
                    surface.SetDrawColor(sp.color.r, sp.color.g, sp.color.b, 230)
                    surface.DrawLine(sp.x, sp.y, tx - math.cos(angle)*3, ty - math.sin(angle)*3)

                    -- Draw dot
                    surface.DrawRect(sp.x - 2, sp.y - 2, 4, 4)

                    -- Draw box and text
                    local tw, th = surface.GetTextSize(sp.name)
                    draw.RoundedBox(4, tx - tw/2 - 5, ty - th/2 - 2, tw + 10, th + 4, Color(15, 15, 15, 230))
                    draw.SimpleText(sp.name, "DermaDefault", tx, ty, sp.color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                else
                    -- Faint dot for out-of-focus bones
                    surface.SetDrawColor(sp.color.r, sp.color.g, sp.color.b, 100)
                    surface.DrawRect(sp.x - 1, sp.y - 1, 2, 2)
                end
            end
            
            -- Draw a subtle diagnostic circle around the crosshair
            surface.SetDrawColor(255, 255, 255, 30)
            local segments = 16
            local radius = 200
            local lastX, lastY = cx + radius, cy
            for j = 1, segments do
                local a = (j / segments) * math.pi * 2
                local nextX = cx + math.cos(a) * radius
                local nextY = cy + math.sin(a) * radius
                surface.DrawLine(lastX, lastY, nextX, nextY)
                lastX, lastY = nextX, nextY
            end
        end)
    else
        hook.Remove("PostDrawViewModel", "DebugDrawViewModelBones")
        hook.Remove("HUDPaint", "DebugDrawBonesHUD")
        if IsValid(LocalPlayer()) then
            LocalPlayer().DebugBonesList = nil
        end
    end
end)

LocalWeaponStatues = LocalWeaponStatues or {}

concommand.Add("gmod_spawn_weapon_statue", function(ply, cmd, args)
    local activeWep = ply:GetActiveWeapon()
    if not IsValid(activeWep) then
        print("[SceneExport] No active weapon found!")
        return
    end

    local vm = ply:GetViewModel()
    if not IsValid(vm) then
        print("[SceneExport] Viewmodel not found!")
        return
    end

    local hands = ply:GetHands()
    if not IsValid(hands) then hands = ply:GetViewModel(1) end
    if not IsValid(hands) then
        print("[SceneExport] Hands entity not found!")
        return
    end

    local tr = ply:GetEyeTrace()
    local spawnPos = tr.HitPos + Vector(0, 0, 5) -- Spawn slightly above ground
    local spawnAng = Angle(0, ply:GetAngles().y + 180, 0) -- Rotate facing player

    -- 1. Spawn hands viewmodel dummy
    local model_hands = hands:GetModel()
    local hands_dummy = ClientsideModel(model_hands)
    if not IsValid(hands_dummy) then
        print("[SceneExport] Failed to spawn hands dummy!")
        return
    end

    hands_dummy:SetPos(spawnPos)
    hands_dummy:SetAngles(spawnAng)
    hands_dummy:SetSkin(hands:GetSkin() or 0)
    hands_dummy.IsWeaponStatue = true
    for _, bg in ipairs(hands:GetBodyGroups() or {}) do
        hands_dummy:SetBodygroup(bg.id, hands:GetBodygroup(bg.id))
    end
    table.insert(LocalWeaponStatues, hands_dummy)

    -- 2. Spawn weapon viewmodel dummy
    local model_wep = vm:GetModel()
    local wep_dummy = ClientsideModel(model_wep)
    if not IsValid(wep_dummy) then
        print("[SceneExport] Failed to spawn weapon dummy!")
        return
    end

    wep_dummy:SetPos(spawnPos)
    wep_dummy:SetAngles(spawnAng)
    wep_dummy:SetSkin(vm:GetSkin() or 0)
    wep_dummy.IsWeaponStatue = true
    for _, bg in ipairs(vm:GetBodyGroups() or {}) do
        wep_dummy:SetBodygroup(bg.id, vm:GetBodygroup(bg.id))
    end
    table.insert(LocalWeaponStatues, wep_dummy)

    -- Calculate base matrices for bone relative posing
    local function SetupDummyBoneCopy(dst, src)
        local src_mat = src:GetWorldTransformMatrix()
        if not src_mat then
            src_mat = Matrix()
            src_mat:Translate(src:GetPos())
            src_mat:SetAngles(src:GetAngles())
        end
        local src_inv = src_mat:GetInverse()
        
        dst.BuildBonePositions = function(self)
            if not IsValid(src) then return end
            local my_mat = self:GetWorldTransformMatrix()
            if not my_mat then return end
            for i = 0, src:GetBoneCount() - 1 do
                local bm = src:GetBoneMatrix(i)
                if bm then
                    local local_bm = src_inv * bm
                    local target_bm = my_mat * local_bm
                    self:SetBoneMatrix(i, target_bm)
                end
            end
        end
    end

    SetupDummyBoneCopy(hands_dummy, hands)
    SetupDummyBoneCopy(wep_dummy, vm)

    -- Map GMod entities to their dummy copies for sub-attachments
    local entity_mapping = {}
    entity_mapping[vm] = wep_dummy
    entity_mapping[activeWep] = wep_dummy

    local function CopyBodygroupsAndSkin(src, dst)
        dst:SetSkin(src:GetSkin() or 0)
        for _, bg in ipairs(src:GetBodyGroups() or {}) do
            dst:SetBodygroup(bg.id, src:GetBodygroup(bg.id))
        end
    end

    -- 3. Spawn VModel parts
    if activeWep.VModel then
        for _, ent in pairs(activeWep.VModel) do
            if IsValid(ent) and not ent.NoDraw then
                local model = ent:GetModel()
                if model and model ~= "" then
                    local part_dummy = ClientsideModel(model)
                    if IsValid(part_dummy) then
                        part_dummy:SetParent(wep_dummy)
                        part_dummy:SetMoveType(MOVETYPE_NONE)
                        part_dummy:AddEffects(EF_BONEMERGE)
                        part_dummy.IsWeaponStatue = true
                        CopyBodygroupsAndSkin(ent, part_dummy)
                        SetupDummyBoneCopy(part_dummy, ent)
                        table.insert(LocalWeaponStatues, part_dummy)
                        entity_mapping[ent] = part_dummy
                    end
                end
            end
        end
    end

    -- 4. Spawn Attachments recursively
    local function SpawnSlotStatue(slots, parent_ent)
        if not slots then return end
        for _, slot in pairs(slots) do
            if IsValid(slot.Ent) and not slot.Ent.NoDraw then
                local model = slot.Ent:GetModel()
                if model and model ~= "" then
                    local att_dummy = ClientsideModel(model)
                    if IsValid(att_dummy) then
                        att_dummy:SetParent(parent_ent)
                        att_dummy:SetMoveType(MOVETYPE_NONE)
                        att_dummy:AddEffects(EF_BONEMERGE)
                        att_dummy.IsWeaponStatue = true
                        CopyBodygroupsAndSkin(slot.Ent, att_dummy)
                        SetupDummyBoneCopy(att_dummy, slot.Ent)
                        table.insert(LocalWeaponStatues, att_dummy)
                        entity_mapping[slot.Ent] = att_dummy
                        
                        if slot.SubAttachments then
                            SpawnSlotStatue(slot.SubAttachments, att_dummy)
                        end
                    end
                end
            end
        end
    end

    if activeWep.Attachments then
        SpawnSlotStatue(activeWep.Attachments, wep_dummy)
    end

    print("[SceneExport] Spawned weapon and hands statue with " .. #LocalWeaponStatues .. " parts!")
end)

concommand.Add("gmod_clear_weapon_statues", function()
    if LocalWeaponStatues then
        for _, ent in ipairs(LocalWeaponStatues) do
            if IsValid(ent) then ent:Remove() end
        end
        LocalWeaponStatues = {}
    end
    print("[SceneExport] Cleared all weapon statues!")
end)
